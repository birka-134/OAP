﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_25
{
    public partial class BMR : Form
    {
        public bool male = false, female = false;
        public DateTime DateEnd;
        public BMR()
        {
            InitializeComponent();
        }

        private void BMR_Load(object sender, EventArgs e)
        {
            button.RoundButton(Cancel, 20);
            button.RoundButton(Calculate, 20);
            button.RoundButton(back, 20);
            DateEnd = new DateTime(2024, 2, 26, 8, 30, 0);
            timer.Start();
            InfoCheck.Visible = false;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            timer_to_begin.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", DateEnd - DateTime.Now);
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void Female_pic_Click(object sender, EventArgs e)
        {
            Female.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
            male = false;
            female = true;
        }

        private void Male_pic_Click(object sender, EventArgs e)
        {
            Male.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
            male = true;
            female = false;
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Height1.Text = "";
            Weight1.Text = "";
            Age.Text = "";
            male = false;
            female = false;

            SitResult.Text = "0";
            SmallActivityResult.Text = "0";
            AverageActivityResult.Text = "0";
            StrongActivityResult.Text = "0";
            MaximumActivityResult.Text = "0";
            Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
            Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            double bmr = 0;
            if (male)
            {
                bmr = 88.36 + 13.4 * Convert.ToInt32(Weight1.Text) + 4.8 * Convert.ToInt32(Height1.Text) - 5.7 * Convert.ToInt32(Age.Text);
            }
            else if (female)
            {
                bmr = 447.6 + 9.2 * Convert.ToInt32(Weight1.Text) + 3.1 * Convert.ToInt32(Height1.Text) - 4.3 * Convert.ToInt32(Age.Text);
            }

            SitResult.Text = Convert.ToString(bmr * 1.2);
            SmallActivityResult.Text = Convert.ToString(bmr * 1.375);
            AverageActivityResult.Text = Convert.ToString(bmr * 1.55);
            StrongActivityResult.Text = Convert.ToString(bmr * 1.725);
            MaximumActivityResult.Text = Convert.ToString(bmr * 1.9);
        }

        private void Info_Click(object sender, EventArgs e)
        {
            InfoCheck.Visible = true;
        }

        private void CloseInfo_Click(object sender, EventArgs e)
        {
            InfoCheck.Visible=false;
        }
    }
}
