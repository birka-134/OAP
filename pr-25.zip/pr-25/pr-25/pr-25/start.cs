﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_25
{
    public partial class begin : Form
    {
        public DateTime DateEnd;
        public begin()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DateEnd = new DateTime(2024, 2, 26, 8, 30, 0);
            timer.Start();
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            timer_to_begin.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", DateEnd - DateTime.Now);
        }
        private void map_bt_Click(object sender, EventArgs e)
        {
            info f1 = new info();
            this.Hide();
            f1.ShowDialog();
            this.Show();
        }

        private void BMI_Click(object sender, EventArgs e)
        {
            BMI f1 = new BMI();
            this.Hide();
            f1.ShowDialog();
            this.Show();
        }

        private void BMR_Click(object sender, EventArgs e)
        {
            BMR f1 = new BMR();
            this.Hide();
            f1.ShowDialog();
            this.Show();
        }

        private void speed_Click(object sender, EventArgs e)
        {
            Faster f1 = new Faster();
            this.Hide();
            f1.ShowDialog();
            this.Show();
        }

    }
}
