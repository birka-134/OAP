﻿namespace pr_25
{
    partial class BMI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BMI));
            this.panel1 = new System.Windows.Forms.Panel();
            this.back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.timer_to_begin = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.BMICalculator = new System.Windows.Forms.Label();
            this.Obese = new System.Windows.Forms.Label();
            this.Over = new System.Windows.Forms.Label();
            this.Healthy = new System.Windows.Forms.Label();
            this.Underweight = new System.Windows.Forms.Label();
            this.nBMI = new System.Windows.Forms.Label();
            this.pObese = new System.Windows.Forms.Panel();
            this.pOver = new System.Windows.Forms.Panel();
            this.pHealthy = new System.Windows.Forms.Panel();
            this.pUnderweight = new System.Windows.Forms.Panel();
            this.bp = new System.Windows.Forms.TrackBar();
            this.Result = new System.Windows.Forms.Panel();
            this.nResult = new System.Windows.Forms.Label();
            this.Result1_pic = new System.Windows.Forms.PictureBox();
            this.Result4_pic = new System.Windows.Forms.PictureBox();
            this.Result3_pic = new System.Windows.Forms.PictureBox();
            this.Result2_pic = new System.Windows.Forms.PictureBox();
            this.Female = new System.Windows.Forms.Panel();
            this.nFemale = new System.Windows.Forms.Label();
            this.Female_pic = new System.Windows.Forms.PictureBox();
            this.Male = new System.Windows.Forms.Panel();
            this.nMale = new System.Windows.Forms.Label();
            this.Male_pic = new System.Windows.Forms.PictureBox();
            this.Cancel = new System.Windows.Forms.Button();
            this.Calculate = new System.Windows.Forms.Button();
            this.Kg = new System.Windows.Forms.Label();
            this.Cm = new System.Windows.Forms.Label();
            this.Weight1 = new System.Windows.Forms.TextBox();
            this.Height1 = new System.Windows.Forms.TextBox();
            this.nWeight = new System.Windows.Forms.Label();
            this.nHeight = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bp)).BeginInit();
            this.Result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Result1_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Result4_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Result3_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Result2_pic)).BeginInit();
            this.Female.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Female_pic)).BeginInit();
            this.Male.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Male_pic)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.back);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-35, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 58);
            this.panel1.TabIndex = 2;
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(61, 20);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 27;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(155, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "MARATHON SKILLS 2016";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.timer_to_begin);
            this.panel2.Location = new System.Drawing.Point(-35, 490);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(959, 42);
            this.panel2.TabIndex = 3;
            // 
            // timer_to_begin
            // 
            this.timer_to_begin.AutoSize = true;
            this.timer_to_begin.Location = new System.Drawing.Point(307, 15);
            this.timer_to_begin.Name = "timer_to_begin";
            this.timer_to_begin.Size = new System.Drawing.Size(269, 13);
            this.timer_to_begin.TabIndex = 0;
            this.timer_to_begin.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // BMICalculator
            // 
            this.BMICalculator.AutoSize = true;
            this.BMICalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BMICalculator.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BMICalculator.Location = new System.Drawing.Point(270, 61);
            this.BMICalculator.Name = "BMICalculator";
            this.BMICalculator.Size = new System.Drawing.Size(206, 29);
            this.BMICalculator.TabIndex = 11;
            this.BMICalculator.Text = "BMI калькулятор";
            // 
            // Obese
            // 
            this.Obese.AutoSize = true;
            this.Obese.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Obese.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Obese.Location = new System.Drawing.Point(763, 441);
            this.Obese.Name = "Obese";
            this.Obese.Size = new System.Drawing.Size(67, 15);
            this.Obese.TabIndex = 54;
            this.Obese.Text = "Ожирение";
            // 
            // Over
            // 
            this.Over.AutoSize = true;
            this.Over.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Over.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Over.Location = new System.Drawing.Point(660, 441);
            this.Over.Name = "Over";
            this.Over.Size = new System.Drawing.Size(81, 15);
            this.Over.TabIndex = 53;
            this.Over.Text = "Избыточный";
            // 
            // Healthy
            // 
            this.Healthy.AutoSize = true;
            this.Healthy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Healthy.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Healthy.Location = new System.Drawing.Point(587, 441);
            this.Healthy.Name = "Healthy";
            this.Healthy.Size = new System.Drawing.Size(66, 15);
            this.Healthy.TabIndex = 52;
            this.Healthy.Text = "Здоровый";
            // 
            // Underweight
            // 
            this.Underweight.AutoSize = true;
            this.Underweight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Underweight.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Underweight.Location = new System.Drawing.Point(463, 441);
            this.Underweight.Name = "Underweight";
            this.Underweight.Size = new System.Drawing.Size(100, 15);
            this.Underweight.TabIndex = 51;
            this.Underweight.Text = "Недостаточный";
            // 
            // nBMI
            // 
            this.nBMI.AutoSize = true;
            this.nBMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nBMI.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nBMI.Location = new System.Drawing.Point(461, 365);
            this.nBMI.Name = "nBMI";
            this.nBMI.Size = new System.Drawing.Size(49, 25);
            this.nBMI.TabIndex = 50;
            this.nBMI.Text = "BMI";
            // 
            // pObese
            // 
            this.pObese.BackColor = System.Drawing.Color.Red;
            this.pObese.Location = new System.Drawing.Point(728, 430);
            this.pObese.Name = "pObese";
            this.pObese.Size = new System.Drawing.Size(135, 8);
            this.pObese.TabIndex = 49;
            // 
            // pOver
            // 
            this.pOver.BackColor = System.Drawing.Color.Gold;
            this.pOver.Location = new System.Drawing.Point(663, 430);
            this.pOver.Name = "pOver";
            this.pOver.Size = new System.Drawing.Size(72, 8);
            this.pOver.TabIndex = 48;
            // 
            // pHealthy
            // 
            this.pHealthy.BackColor = System.Drawing.Color.Lime;
            this.pHealthy.Location = new System.Drawing.Point(576, 430);
            this.pHealthy.Name = "pHealthy";
            this.pHealthy.Size = new System.Drawing.Size(91, 8);
            this.pHealthy.TabIndex = 47;
            // 
            // pUnderweight
            // 
            this.pUnderweight.BackColor = System.Drawing.Color.Gold;
            this.pUnderweight.Location = new System.Drawing.Point(467, 430);
            this.pUnderweight.Name = "pUnderweight";
            this.pUnderweight.Size = new System.Drawing.Size(110, 8);
            this.pUnderweight.TabIndex = 46;
            // 
            // bp
            // 
            this.bp.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.bp.BackColor = System.Drawing.SystemColors.Control;
            this.bp.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.bp.Location = new System.Drawing.Point(465, 393);
            this.bp.Maximum = 40;
            this.bp.Minimum = 10;
            this.bp.Name = "bp";
            this.bp.Size = new System.Drawing.Size(400, 45);
            this.bp.TabIndex = 45;
            this.bp.TickStyle = System.Windows.Forms.TickStyle.None;
            this.bp.Value = 10;
            // 
            // Result
            // 
            this.Result.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Result.Controls.Add(this.Result4_pic);
            this.Result.Controls.Add(this.Result3_pic);
            this.Result.Controls.Add(this.Result2_pic);
            this.Result.Controls.Add(this.nResult);
            this.Result.Controls.Add(this.Result1_pic);
            this.Result.Location = new System.Drawing.Point(576, 76);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(187, 234);
            this.Result.TabIndex = 44;
            // 
            // nResult
            // 
            this.nResult.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nResult.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nResult.Location = new System.Drawing.Point(1, 208);
            this.nResult.Name = "nResult";
            this.nResult.Size = new System.Drawing.Size(184, 20);
            this.nResult.TabIndex = 15;
            this.nResult.Text = "Ожирение";
            this.nResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Result1_pic
            // 
            this.Result1_pic.Image = ((System.Drawing.Image)(resources.GetObject("Result1_pic.Image")));
            this.Result1_pic.Location = new System.Drawing.Point(34, 23);
            this.Result1_pic.Name = "Result1_pic";
            this.Result1_pic.Size = new System.Drawing.Size(125, 176);
            this.Result1_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Result1_pic.TabIndex = 14;
            this.Result1_pic.TabStop = false;
            // 
            // Result4_pic
            // 
            this.Result4_pic.Image = ((System.Drawing.Image)(resources.GetObject("Result4_pic.Image")));
            this.Result4_pic.Location = new System.Drawing.Point(34, 23);
            this.Result4_pic.Name = "Result4_pic";
            this.Result4_pic.Size = new System.Drawing.Size(125, 176);
            this.Result4_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Result4_pic.TabIndex = 18;
            this.Result4_pic.TabStop = false;
            this.Result4_pic.Visible = false;
            // 
            // Result3_pic
            // 
            this.Result3_pic.Image = ((System.Drawing.Image)(resources.GetObject("Result3_pic.Image")));
            this.Result3_pic.Location = new System.Drawing.Point(34, 23);
            this.Result3_pic.Name = "Result3_pic";
            this.Result3_pic.Size = new System.Drawing.Size(125, 176);
            this.Result3_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Result3_pic.TabIndex = 17;
            this.Result3_pic.TabStop = false;
            // 
            // Result2_pic
            // 
            this.Result2_pic.Image = ((System.Drawing.Image)(resources.GetObject("Result2_pic.Image")));
            this.Result2_pic.Location = new System.Drawing.Point(34, 24);
            this.Result2_pic.Name = "Result2_pic";
            this.Result2_pic.Size = new System.Drawing.Size(125, 176);
            this.Result2_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Result2_pic.TabIndex = 16;
            this.Result2_pic.TabStop = false;
            // 
            // Female
            // 
            this.Female.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Female.Controls.Add(this.nFemale);
            this.Female.Controls.Add(this.Female_pic);
            this.Female.Location = new System.Drawing.Point(202, 124);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(140, 152);
            this.Female.TabIndex = 43;
            // 
            // nFemale
            // 
            this.nFemale.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nFemale.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nFemale.Location = new System.Drawing.Point(31, 121);
            this.nFemale.Name = "nFemale";
            this.nFemale.Size = new System.Drawing.Size(85, 22);
            this.nFemale.TabIndex = 15;
            this.nFemale.Text = "Женский";
            this.nFemale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Female_pic
            // 
            this.Female_pic.Image = ((System.Drawing.Image)(resources.GetObject("Female_pic.Image")));
            this.Female_pic.Location = new System.Drawing.Point(31, 12);
            this.Female_pic.Name = "Female_pic";
            this.Female_pic.Size = new System.Drawing.Size(85, 106);
            this.Female_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Female_pic.TabIndex = 14;
            this.Female_pic.TabStop = false;
            this.Female_pic.Click += new System.EventHandler(this.Female_pic_Click);
            // 
            // Male
            // 
            this.Male.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Male.Controls.Add(this.nMale);
            this.Male.Controls.Add(this.Male_pic);
            this.Male.Location = new System.Drawing.Point(24, 124);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(140, 152);
            this.Male.TabIndex = 42;
            // 
            // nMale
            // 
            this.nMale.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nMale.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nMale.Location = new System.Drawing.Point(27, 121);
            this.nMale.Name = "nMale";
            this.nMale.Size = new System.Drawing.Size(79, 22);
            this.nMale.TabIndex = 15;
            this.nMale.Text = "Мужской";
            this.nMale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Male_pic
            // 
            this.Male_pic.Image = ((System.Drawing.Image)(resources.GetObject("Male_pic.Image")));
            this.Male_pic.Location = new System.Drawing.Point(27, 12);
            this.Male_pic.Name = "Male_pic";
            this.Male_pic.Size = new System.Drawing.Size(85, 106);
            this.Male_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Male_pic.TabIndex = 14;
            this.Male_pic.TabStop = false;
            this.Male_pic.Click += new System.EventHandler(this.Male_pic_Click);
            // 
            // Cancel
            // 
            this.Cancel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Cancel.FlatAppearance.BorderSize = 0;
            this.Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Cancel.Location = new System.Drawing.Point(192, 403);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 41;
            this.Cancel.Text = "Отмена";
            this.Cancel.UseVisualStyleBackColor = false;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Calculate
            // 
            this.Calculate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Calculate.FlatAppearance.BorderSize = 0;
            this.Calculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Calculate.Location = new System.Drawing.Point(66, 403);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(98, 23);
            this.Calculate.TabIndex = 40;
            this.Calculate.Text = "Рассчитать";
            this.Calculate.UseVisualStyleBackColor = false;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Kg
            // 
            this.Kg.AutoSize = true;
            this.Kg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Kg.Location = new System.Drawing.Point(210, 354);
            this.Kg.Name = "Kg";
            this.Kg.Size = new System.Drawing.Size(20, 16);
            this.Kg.TabIndex = 39;
            this.Kg.Text = "кг";
            // 
            // Cm
            // 
            this.Cm.AutoSize = true;
            this.Cm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Cm.Location = new System.Drawing.Point(210, 318);
            this.Cm.Name = "Cm";
            this.Cm.Size = new System.Drawing.Size(23, 16);
            this.Cm.TabIndex = 38;
            this.Cm.Text = "см";
            // 
            // Weight1
            // 
            this.Weight1.Location = new System.Drawing.Point(136, 350);
            this.Weight1.Name = "Weight1";
            this.Weight1.Size = new System.Drawing.Size(68, 20);
            this.Weight1.TabIndex = 37;
            // 
            // Height1
            // 
            this.Height1.Location = new System.Drawing.Point(136, 314);
            this.Height1.Name = "Height1";
            this.Height1.Size = new System.Drawing.Size(68, 20);
            this.Height1.TabIndex = 36;
            // 
            // nWeight
            // 
            this.nWeight.AutoSize = true;
            this.nWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nWeight.Location = new System.Drawing.Point(95, 354);
            this.nWeight.Name = "nWeight";
            this.nWeight.Size = new System.Drawing.Size(34, 16);
            this.nWeight.TabIndex = 35;
            this.nWeight.Text = "Вес:";
            // 
            // nHeight
            // 
            this.nHeight.AutoSize = true;
            this.nHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nHeight.Location = new System.Drawing.Point(88, 318);
            this.nHeight.Name = "nHeight";
            this.nHeight.Size = new System.Drawing.Size(41, 16);
            this.nHeight.TabIndex = 34;
            this.nHeight.Text = "Рост:";
            // 
            // BMI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.Obese);
            this.Controls.Add(this.Over);
            this.Controls.Add(this.Healthy);
            this.Controls.Add(this.Underweight);
            this.Controls.Add(this.nBMI);
            this.Controls.Add(this.pObese);
            this.Controls.Add(this.pOver);
            this.Controls.Add(this.pHealthy);
            this.Controls.Add(this.pUnderweight);
            this.Controls.Add(this.bp);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.Female);
            this.Controls.Add(this.Male);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.Kg);
            this.Controls.Add(this.Cm);
            this.Controls.Add(this.Weight1);
            this.Controls.Add(this.Height1);
            this.Controls.Add(this.nWeight);
            this.Controls.Add(this.nHeight);
            this.Controls.Add(this.BMICalculator);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "BMI";
            this.Text = "BMI";
            this.Load += new System.EventHandler(this.BMI_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bp)).EndInit();
            this.Result.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Result1_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Result4_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Result3_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Result2_pic)).EndInit();
            this.Female.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Female_pic)).EndInit();
            this.Male.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Male_pic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label timer_to_begin;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button back;
        public System.Windows.Forms.Label BMICalculator;
        public System.Windows.Forms.Label Obese;
        public System.Windows.Forms.Label Over;
        public System.Windows.Forms.Label Healthy;
        public System.Windows.Forms.Label Underweight;
        public System.Windows.Forms.Label nBMI;
        private System.Windows.Forms.Panel pObese;
        private System.Windows.Forms.Panel pOver;
        private System.Windows.Forms.Panel pHealthy;
        private System.Windows.Forms.Panel pUnderweight;
        private System.Windows.Forms.TrackBar bp;
        private System.Windows.Forms.Panel Result;
        private System.Windows.Forms.PictureBox Result4_pic;
        private System.Windows.Forms.PictureBox Result3_pic;
        private System.Windows.Forms.PictureBox Result2_pic;
        private System.Windows.Forms.Label nResult;
        private System.Windows.Forms.PictureBox Result1_pic;
        private System.Windows.Forms.Panel Female;
        private System.Windows.Forms.Label nFemale;
        private System.Windows.Forms.PictureBox Female_pic;
        private System.Windows.Forms.Panel Male;
        private System.Windows.Forms.Label nMale;
        private System.Windows.Forms.PictureBox Male_pic;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Label Kg;
        private System.Windows.Forms.Label Cm;
        private System.Windows.Forms.TextBox Weight1;
        private System.Windows.Forms.TextBox Height1;
        private System.Windows.Forms.Label nWeight;
        private System.Windows.Forms.Label nHeight;
    }
}