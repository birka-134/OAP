﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace pr_25
{
    public partial class Faster : Form
    {
        public DateTime DateEnd;
        public Faster()
        {
            InitializeComponent();
        }
        private void Who_faster_Load(object sender, EventArgs e)
        {
            button.RoundButton(back, 20);
            DateEnd = new DateTime(2024, 2, 26, 8, 30, 0);
            timer.Start();
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            timer_to_begin.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", DateEnd - DateTime.Now);
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public string Time(double a)
        {
            double time = 42 / a;
            string Time = time + "ч";
            if (time<1)
            {
                time = Math.Round(time*60);
                Time = time + "м";
            }
            return Time;
        }
        private void F1Car_picture_Click(object sender, EventArgs e)
        {
            double speed = 345;
            Name1.Text = F1Car.Text;
            ItemPhoto.Image = F1Car_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void Worm_picture_Click(object sender, EventArgs e)
        {
            double speed = 0.03;
            Name1.Text = Worm.Text;
            ItemPhoto.Image = Worm_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void Sloth_picture_Click(object sender, EventArgs e)
        {
            double speed = 0.12;
            Name1.Text = Sloth.Text;
            ItemPhoto.Image = Sloth_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void Capybara_picture_Click(object sender, EventArgs e)
        {
            double speed = 35;
            Name1.Text = Capybara.Text;
            ItemPhoto.Image = Capybara_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void Jaguar_picture_Click(object sender, EventArgs e)
        {
            double speed = 80;
            Name1.Text = Jaguar.Text;
            ItemPhoto.Image = Jaguar_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void Slug_picture_Click(object sender, EventArgs e)
        {
            double speed = 0.01;
            Name1.Text = Slug.Text;
            ItemPhoto.Image = Slug_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void Horse_picture_Click(object sender, EventArgs e)
        {
            double speed = 15;
            Name1.Text = Horse.Text;
            ItemPhoto.Image = Horse_picture.Image;
            Info.Text = "Максимальная скорость " + Name1.Text + " " + speed + " км/ч. Это займет " + Time(speed) + ", чтобы завершить 42 км марафона";
            Name1.Visible = true;
        }

        private void AirbusA380_picture_Click(object sender, EventArgs e)
        {
            double length = 73;
            double quantity = Math.Round(42000 / length, 2);
            Name1.Text = AirbusA380.Text;
            ItemPhoto.Image = AirbusA380_picture.Image;
            Info.Text = "Длина " + Name1.Text + " " + length + " м. Нужно " + quantity + " таких, чтобы покрыть расстояние в 42 км марафона";
            Item.Visible = true;
        }

        private void Havaianas_picture_Click(object sender, EventArgs e)
        {
            double length = 0.245;
            double quantity = Math.Round(42000 / length, 2);
            Name1.Text = Havaianas.Text;
            ItemPhoto.Image = Havaianas_picture.Image;
            Info.Text = "Длина " + Name1.Text + " " + length + " м. Нужно " + quantity + " таких, чтобы покрыть расстояние в 42 км марафона";
            Item.Visible = true;
        }

        private void FootballField_picture_Click(object sender, EventArgs e)
        {
            double length = 105;
            double quantity = Math.Round(42000 / length, 2);
            Name1.Text = FootballField.Text;
            ItemPhoto.Image = FootballField_picture.Image;
            Info.Text = "Длина " + Name1.Text + " " + length + " м. Нужно " + quantity + " таких, чтобы покрыть расстояние в 42 км марафона";
            Item.Visible = true;
        }

        private void Ronaldinho_picture_Click(object sender, EventArgs e)
        {
            double length = 1.81;
            double quantity = Math.Round(42000 / length, 2);
            Name1.Text = Ronaldinho.Text;
            ItemPhoto.Image = Ronaldinho_picture.Image;
            Info.Text = "Длина " + Name1.Text + " " + length + " м. Нужно " + quantity + " таких, чтобы покрыть расстояние в 42 км марафона";
            Item.Visible = true;
        }

        private void Bus_picture_Click(object sender, EventArgs e)
        {
            double length = 10;
            double quantity = Math.Round(42000 / length, 2);
            Name1.Text = Bus.Text;
            ItemPhoto.Image = Bus_picture.Image;
            Info.Text = "Длина " + Name1.Text + " " + length + " м. Нужно " + quantity + " таких, чтобы покрыть расстояние в 42 км марафона";
            Item.Visible = true;
        }
    }
}
