﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_25
{
    public partial class BMI : Form
    {
        public DateTime DateEnd;
        public BMI()
        {
            InitializeComponent();
        }

        private void BMI_Load(object sender, EventArgs e)
        {
            Result.Visible = false;
            nBMI.Visible = false;
            button.RoundButton(Cancel, 20);
            button.RoundButton(Calculate, 20);
            button.RoundButton(back, 20);
            DateEnd = new DateTime(2024, 2, 26, 8, 30, 0);
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            timer_to_begin.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", DateEnd - DateTime.Now);
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            Height1.Text = "";
            Weight1.Text = "";
            Result.Visible = false;
            nBMI.Visible = false;
            Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
            Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
        }

        private void Male_pic_Click(object sender, EventArgs e)
        {
            Male.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
        }

        private void Female_pic_Click(object sender, EventArgs e)
        {
            Female.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            //Результат
            Result.Visible = true;
            double bmi = Convert.ToDouble(Weight1.Text) / ((Convert.ToDouble(Height1.Text)/ 100) * ((Convert.ToDouble(Height1.Text) / 100)));
            //картинки
            if (bmi < 18.5)
            {
                Result1_pic.Visible = true;
                Result2_pic.Visible = false;
                Result3_pic.Visible = false;
                Result4_pic.Visible = false;
                nResult.Text = "Недостаточный вес";
            }
            else if (bmi >= 18.5 && bmi <= 24.9)
            {
                Result1_pic.Visible = false;
                Result2_pic.Visible = true;
                Result3_pic.Visible = false;
                Result4_pic.Visible = false;
                nResult.Text = "Здоровый вес";
            }
            else if (bmi >= 25 && bmi <= 29.9)
            {
                Result1_pic.Visible = false;
                Result2_pic.Visible = false;
                Result3_pic.Visible = true;
                Result4_pic.Visible = false;
                nResult.Text = "Избыточный вес";
            }
            else if (bmi >= 30)
            {
                Result1_pic.Visible = false;
                Result2_pic.Visible = false;
                Result3_pic.Visible = false;
                Result4_pic.Visible = true;
                nResult.Text = "Ожирение";
            }
            //ползунок
            nBMI.Text = Convert.ToString(Math.Round(bmi, 1));

            if (bmi <= 10)
            {
                bp.Value = 10;
                nBMI.Location = new Point(475, nBMI.Location.Y);
            }
            else if (bmi >= 40)
            {
                bp.Value = 40;
                nBMI.Location = new Point(820, nBMI.Location.Y);
            }
            else
            {
                bp.Value = Convert.ToInt32(bmi);
                nBMI.Location = new Point(Convert.ToInt32(375 + bmi * 11.5), nBMI.Location.Y);

            }
            nBMI.Visible = true;
        }
    }
}
