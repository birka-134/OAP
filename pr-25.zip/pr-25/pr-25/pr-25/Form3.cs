﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_25
{
    public partial class intMap : Form
    {
        
        public intMap()
        {
            
            InitializeComponent();
        }
        
		private void ch1_Click(object sender, EventArgs e)
		{
            begin f = new begin();
            f.Show();
        }
	}
}
