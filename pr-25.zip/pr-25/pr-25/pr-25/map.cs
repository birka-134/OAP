﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_25
{
    public partial class intMap : Form
    {
        
        public intMap()
        {
            
            InitializeComponent();
        }
        
		

		private void intMap_Load(object sender, EventArgs e)
		{
			button.RoundButton(back, 20);
			button.RoundButton(start_m, 20);
		

			button.RoundButton(ch1, 30);
			button.RoundButton(ch2, 30);
			button.RoundButton(ch3, 30);
			button.RoundButton(ch4, 30);
			button.RoundButton(ch5, 30);
			button.RoundButton(ch6, 30);
			button.RoundButton(ch7, 30);
			button.RoundButton(ch8, 30);

			infoCheck.Visible = false;
			drinks.Visible = false;
			energy.Visible = false;
			toulet.Visible = false;
			info.Visible = false;
			medic.Visible = false;

		}

		private void back_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void start_m_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Race Start";
			description.Text = "Full Marathon";
            drinks.Visible = false;
            energy.Visible = false;
            toulet.Visible = false;
            info.Visible = false;
            medic.Visible = false;
        }

		private void close_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = false;
		}
		private void ch1_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Avenida Rudge";
			description.Text = "Стенд питья \n\nЭнергетические батончики";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = false;
			info.Visible = false;
			medic.Visible = false;
		}
		private void ch2_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Theatro Municipal";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Информационный центр \n\n Медицинский пункт";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = true;
			medic.Visible = true;
			medic.Location = new Point(19, 212);
		}
		private void ch3_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Parque do Ibirapuera";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = false;
			medic.Visible = false;
		}

		private void ch4_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Jardim Luzitania";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Медицинский пункт";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = false;
			medic.Visible = true;
            medic.Location = new Point(19, 172);
        }

        private void ch5_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Iguatemi";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Информационный центр";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = true;
			medic.Visible = false;
		}

		private void ch6_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Rua Lisboa";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = false;
			medic.Visible = false;
		}

		private void ch7_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Cemitério da Consolação";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Информационный центр \n\n Медицинский пункт";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = true;
			medic.Visible = true;
			medic.Location = new Point(19, 212);
		}

		private void ch8_Click(object sender, EventArgs e)
		{
			infoCheck.Visible = true;
			infCheck.Text = "Cemitério da Consolação";
			description.Text = "Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Информационный центр \n\n Медицинский пункт";
			drinks.Visible = true;
			energy.Visible = true;
			toulet.Visible = true;
			info.Visible = true;
			medic.Visible = true;
			medic.Location = new Point(19, 212);
		}
	}
}
