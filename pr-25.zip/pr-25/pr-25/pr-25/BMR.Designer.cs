﻿namespace pr_25
{
    partial class BMR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BMR));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.timer_to_begin = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.back = new System.Windows.Forms.Button();
            this.nBMRCalculator = new System.Windows.Forms.Label();
            this.Female = new System.Windows.Forms.Panel();
            this.nFemale = new System.Windows.Forms.Label();
            this.Female_pic = new System.Windows.Forms.PictureBox();
            this.Male = new System.Windows.Forms.Panel();
            this.nMale = new System.Windows.Forms.Label();
            this.Male_pic = new System.Windows.Forms.PictureBox();
            this.Kg = new System.Windows.Forms.Label();
            this.Cm = new System.Windows.Forms.Label();
            this.Weight1 = new System.Windows.Forms.TextBox();
            this.Height1 = new System.Windows.Forms.TextBox();
            this.nWeight = new System.Windows.Forms.Label();
            this.nHeight = new System.Windows.Forms.Label();
            this.Age = new System.Windows.Forms.TextBox();
            this.nAge = new System.Windows.Forms.Label();
            this.Cancel = new System.Windows.Forms.Button();
            this.Calculate = new System.Windows.Forms.Button();
            this.Info = new System.Windows.Forms.PictureBox();
            this.MaximumActivityResult = new System.Windows.Forms.Label();
            this.StrongActivityResult = new System.Windows.Forms.Label();
            this.AverageActivityResult = new System.Windows.Forms.Label();
            this.SmallActivityResult = new System.Windows.Forms.Label();
            this.SitResult = new System.Windows.Forms.Label();
            this.MaximumActivity = new System.Windows.Forms.Label();
            this.StrongActivity = new System.Windows.Forms.Label();
            this.AverageActivity = new System.Windows.Forms.Label();
            this.SmallActivity = new System.Windows.Forms.Label();
            this.Sit = new System.Windows.Forms.Label();
            this.YourBMR = new System.Windows.Forms.Label();
            this.Expenses = new System.Windows.Forms.Label();
            this.InfoCheck = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.CloseInfo = new System.Windows.Forms.PictureBox();
            this.Description = new System.Windows.Forms.Label();
            this.ActivityLevels = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Female.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Female_pic)).BeginInit();
            this.Male.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Male_pic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Info)).BeginInit();
            this.InfoCheck.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CloseInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-35, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 58);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(155, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "MARATHON SKILLS 2016";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.timer_to_begin);
            this.panel2.Location = new System.Drawing.Point(-35, 490);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(959, 42);
            this.panel2.TabIndex = 3;
            // 
            // timer_to_begin
            // 
            this.timer_to_begin.AutoSize = true;
            this.timer_to_begin.Location = new System.Drawing.Point(307, 15);
            this.timer_to_begin.Name = "timer_to_begin";
            this.timer_to_begin.Size = new System.Drawing.Size(269, 13);
            this.timer_to_begin.TabIndex = 0;
            this.timer_to_begin.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.SystemColors.ControlLight;
            this.back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.Location = new System.Drawing.Point(26, 20);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 27;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // nBMRCalculator
            // 
            this.nBMRCalculator.AutoSize = true;
            this.nBMRCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nBMRCalculator.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nBMRCalculator.Location = new System.Drawing.Point(247, 61);
            this.nBMRCalculator.Name = "nBMRCalculator";
            this.nBMRCalculator.Size = new System.Drawing.Size(217, 29);
            this.nBMRCalculator.TabIndex = 28;
            this.nBMRCalculator.Text = "BMR калькулятор";
            // 
            // Female
            // 
            this.Female.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Female.Controls.Add(this.nFemale);
            this.Female.Controls.Add(this.Female_pic);
            this.Female.Location = new System.Drawing.Point(204, 130);
            this.Female.Name = "Female";
            this.Female.Size = new System.Drawing.Size(140, 152);
            this.Female.TabIndex = 51;
            // 
            // nFemale
            // 
            this.nFemale.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nFemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nFemale.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nFemale.Location = new System.Drawing.Point(31, 121);
            this.nFemale.Name = "nFemale";
            this.nFemale.Size = new System.Drawing.Size(85, 22);
            this.nFemale.TabIndex = 15;
            this.nFemale.Text = "Женский";
            this.nFemale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Female_pic
            // 
            this.Female_pic.Image = ((System.Drawing.Image)(resources.GetObject("Female_pic.Image")));
            this.Female_pic.Location = new System.Drawing.Point(31, 12);
            this.Female_pic.Name = "Female_pic";
            this.Female_pic.Size = new System.Drawing.Size(85, 106);
            this.Female_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Female_pic.TabIndex = 14;
            this.Female_pic.TabStop = false;
            this.Female_pic.Click += new System.EventHandler(this.Female_pic_Click);
            // 
            // Male
            // 
            this.Male.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Male.Controls.Add(this.nMale);
            this.Male.Controls.Add(this.Male_pic);
            this.Male.Location = new System.Drawing.Point(26, 130);
            this.Male.Name = "Male";
            this.Male.Size = new System.Drawing.Size(140, 152);
            this.Male.TabIndex = 50;
            // 
            // nMale
            // 
            this.nMale.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nMale.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nMale.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nMale.Location = new System.Drawing.Point(27, 121);
            this.nMale.Name = "nMale";
            this.nMale.Size = new System.Drawing.Size(79, 22);
            this.nMale.TabIndex = 15;
            this.nMale.Text = "Мужской";
            this.nMale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Male_pic
            // 
            this.Male_pic.Image = ((System.Drawing.Image)(resources.GetObject("Male_pic.Image")));
            this.Male_pic.Location = new System.Drawing.Point(27, 12);
            this.Male_pic.Name = "Male_pic";
            this.Male_pic.Size = new System.Drawing.Size(85, 106);
            this.Male_pic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Male_pic.TabIndex = 14;
            this.Male_pic.TabStop = false;
            this.Male_pic.Click += new System.EventHandler(this.Male_pic_Click);
            // 
            // Kg
            // 
            this.Kg.AutoSize = true;
            this.Kg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Kg.Location = new System.Drawing.Point(212, 360);
            this.Kg.Name = "Kg";
            this.Kg.Size = new System.Drawing.Size(20, 16);
            this.Kg.TabIndex = 49;
            this.Kg.Text = "кг";
            // 
            // Cm
            // 
            this.Cm.AutoSize = true;
            this.Cm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Cm.Location = new System.Drawing.Point(212, 324);
            this.Cm.Name = "Cm";
            this.Cm.Size = new System.Drawing.Size(23, 16);
            this.Cm.TabIndex = 48;
            this.Cm.Text = "см";
            // 
            // Weight1
            // 
            this.Weight1.Location = new System.Drawing.Point(138, 356);
            this.Weight1.Name = "Weight1";
            this.Weight1.Size = new System.Drawing.Size(68, 20);
            this.Weight1.TabIndex = 47;
            // 
            // Height1
            // 
            this.Height1.Location = new System.Drawing.Point(138, 320);
            this.Height1.Name = "Height1";
            this.Height1.Size = new System.Drawing.Size(68, 20);
            this.Height1.TabIndex = 46;
            // 
            // nWeight
            // 
            this.nWeight.AutoSize = true;
            this.nWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nWeight.Location = new System.Drawing.Point(97, 360);
            this.nWeight.Name = "nWeight";
            this.nWeight.Size = new System.Drawing.Size(34, 16);
            this.nWeight.TabIndex = 45;
            this.nWeight.Text = "Вес:";
            // 
            // nHeight
            // 
            this.nHeight.AutoSize = true;
            this.nHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nHeight.Location = new System.Drawing.Point(90, 324);
            this.nHeight.Name = "nHeight";
            this.nHeight.Size = new System.Drawing.Size(41, 16);
            this.nHeight.TabIndex = 44;
            this.nHeight.Text = "Рост:";
            // 
            // Age
            // 
            this.Age.Location = new System.Drawing.Point(138, 392);
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(68, 20);
            this.Age.TabIndex = 53;
            // 
            // nAge
            // 
            this.nAge.AutoSize = true;
            this.nAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nAge.Location = new System.Drawing.Point(73, 393);
            this.nAge.Name = "nAge";
            this.nAge.Size = new System.Drawing.Size(65, 16);
            this.nAge.TabIndex = 52;
            this.nAge.Text = "Возраст:";
            // 
            // Cancel
            // 
            this.Cancel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Cancel.FlatAppearance.BorderSize = 0;
            this.Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Cancel.Location = new System.Drawing.Point(204, 435);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 55;
            this.Cancel.Text = "Отмена";
            this.Cancel.UseVisualStyleBackColor = false;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Calculate
            // 
            this.Calculate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Calculate.FlatAppearance.BorderSize = 0;
            this.Calculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Calculate.Location = new System.Drawing.Point(78, 435);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(98, 23);
            this.Calculate.TabIndex = 54;
            this.Calculate.Text = "Рассчитать";
            this.Calculate.UseVisualStyleBackColor = false;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Info
            // 
            this.Info.Image = ((System.Drawing.Image)(resources.GetObject("Info.Image")));
            this.Info.Location = new System.Drawing.Point(753, 260);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(25, 25);
            this.Info.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Info.TabIndex = 68;
            this.Info.TabStop = false;
            this.Info.Click += new System.EventHandler(this.Info_Click);
            // 
            // MaximumActivityResult
            // 
            this.MaximumActivityResult.AutoSize = true;
            this.MaximumActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaximumActivityResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.MaximumActivityResult.Location = new System.Drawing.Point(758, 454);
            this.MaximumActivityResult.Name = "MaximumActivityResult";
            this.MaximumActivityResult.Size = new System.Drawing.Size(20, 24);
            this.MaximumActivityResult.TabIndex = 67;
            this.MaximumActivityResult.Text = "0";
            // 
            // StrongActivityResult
            // 
            this.StrongActivityResult.AutoSize = true;
            this.StrongActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StrongActivityResult.ForeColor = System.Drawing.Color.Coral;
            this.StrongActivityResult.Location = new System.Drawing.Point(758, 416);
            this.StrongActivityResult.Name = "StrongActivityResult";
            this.StrongActivityResult.Size = new System.Drawing.Size(20, 24);
            this.StrongActivityResult.TabIndex = 66;
            this.StrongActivityResult.Text = "0";
            // 
            // AverageActivityResult
            // 
            this.AverageActivityResult.AutoSize = true;
            this.AverageActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AverageActivityResult.ForeColor = System.Drawing.Color.DarkKhaki;
            this.AverageActivityResult.Location = new System.Drawing.Point(758, 377);
            this.AverageActivityResult.Name = "AverageActivityResult";
            this.AverageActivityResult.Size = new System.Drawing.Size(20, 24);
            this.AverageActivityResult.TabIndex = 65;
            this.AverageActivityResult.Text = "0";
            // 
            // SmallActivityResult
            // 
            this.SmallActivityResult.AutoSize = true;
            this.SmallActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SmallActivityResult.ForeColor = System.Drawing.Color.Green;
            this.SmallActivityResult.Location = new System.Drawing.Point(758, 341);
            this.SmallActivityResult.Name = "SmallActivityResult";
            this.SmallActivityResult.Size = new System.Drawing.Size(20, 24);
            this.SmallActivityResult.TabIndex = 64;
            this.SmallActivityResult.Text = "0";
            // 
            // SitResult
            // 
            this.SitResult.AutoSize = true;
            this.SitResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SitResult.ForeColor = System.Drawing.Color.Blue;
            this.SitResult.Location = new System.Drawing.Point(758, 305);
            this.SitResult.Name = "SitResult";
            this.SitResult.Size = new System.Drawing.Size(20, 24);
            this.SitResult.TabIndex = 63;
            this.SitResult.Text = "0";
            // 
            // MaximumActivity
            // 
            this.MaximumActivity.AutoSize = true;
            this.MaximumActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaximumActivity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.MaximumActivity.Location = new System.Drawing.Point(484, 454);
            this.MaximumActivity.Name = "MaximumActivity";
            this.MaximumActivity.Size = new System.Drawing.Size(255, 24);
            this.MaximumActivity.TabIndex = 62;
            this.MaximumActivity.Text = "Максимальная активность:";
            // 
            // StrongActivity
            // 
            this.StrongActivity.AutoSize = true;
            this.StrongActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StrongActivity.ForeColor = System.Drawing.Color.Coral;
            this.StrongActivity.Location = new System.Drawing.Point(484, 416);
            this.StrongActivity.Name = "StrongActivity";
            this.StrongActivity.Size = new System.Drawing.Size(200, 24);
            this.StrongActivity.TabIndex = 61;
            this.StrongActivity.Text = "Сильная активность:";
            // 
            // AverageActivity
            // 
            this.AverageActivity.AutoSize = true;
            this.AverageActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AverageActivity.ForeColor = System.Drawing.Color.DarkKhaki;
            this.AverageActivity.Location = new System.Drawing.Point(484, 377);
            this.AverageActivity.Name = "AverageActivity";
            this.AverageActivity.Size = new System.Drawing.Size(202, 24);
            this.AverageActivity.TabIndex = 60;
            this.AverageActivity.Text = "Средняя активность:";
            // 
            // SmallActivity
            // 
            this.SmallActivity.AutoSize = true;
            this.SmallActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SmallActivity.ForeColor = System.Drawing.Color.Green;
            this.SmallActivity.Location = new System.Drawing.Point(484, 341);
            this.SmallActivity.Name = "SmallActivity";
            this.SmallActivity.Size = new System.Drawing.Size(222, 24);
            this.SmallActivity.TabIndex = 59;
            this.SmallActivity.Text = "Маленькая активность:";
            // 
            // Sit
            // 
            this.Sit.AutoSize = true;
            this.Sit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sit.ForeColor = System.Drawing.Color.Blue;
            this.Sit.Location = new System.Drawing.Point(484, 305);
            this.Sit.Name = "Sit";
            this.Sit.Size = new System.Drawing.Size(93, 24);
            this.Sit.TabIndex = 58;
            this.Sit.Text = "Сидячий:";
            // 
            // YourBMR
            // 
            this.YourBMR.AutoSize = true;
            this.YourBMR.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.YourBMR.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.YourBMR.Location = new System.Drawing.Point(597, 222);
            this.YourBMR.Name = "YourBMR";
            this.YourBMR.Size = new System.Drawing.Size(121, 29);
            this.YourBMR.TabIndex = 57;
            this.YourBMR.Text = "Ваш BMR";
            // 
            // Expenses
            // 
            this.Expenses.AutoSize = true;
            this.Expenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Expenses.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Expenses.Location = new System.Drawing.Point(516, 262);
            this.Expenses.Name = "Expenses";
            this.Expenses.Size = new System.Drawing.Size(202, 24);
            this.Expenses.TabIndex = 56;
            this.Expenses.Text = "Ежедневно тратится";
            // 
            // InfoCheck
            // 
            this.InfoCheck.BackColor = System.Drawing.SystemColors.ControlLight;
            this.InfoCheck.Controls.Add(this.label10);
            this.InfoCheck.Controls.Add(this.label9);
            this.InfoCheck.Controls.Add(this.label8);
            this.InfoCheck.Controls.Add(this.label7);
            this.InfoCheck.Controls.Add(this.label6);
            this.InfoCheck.Controls.Add(this.label5);
            this.InfoCheck.Controls.Add(this.label4);
            this.InfoCheck.Controls.Add(this.label2);
            this.InfoCheck.Controls.Add(this.label11);
            this.InfoCheck.Controls.Add(this.label12);
            this.InfoCheck.Controls.Add(this.CloseInfo);
            this.InfoCheck.Controls.Add(this.Description);
            this.InfoCheck.Controls.Add(this.ActivityLevels);
            this.InfoCheck.Location = new System.Drawing.Point(161, 98);
            this.InfoCheck.Name = "InfoCheck";
            this.InfoCheck.Size = new System.Drawing.Size(568, 303);
            this.InfoCheck.TabIndex = 69;
            this.InfoCheck.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(275, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(264, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "тренировки чаще, чем раз в день";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(223, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(336, 20);
            this.label9.TabIndex = 29;
            this.label9.Text = "интенсивные тренировки 6-7 раз в неделю";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(224, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(232, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "тренировки 3-5 раз в неделю";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(244, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(241, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "тренировки 1-3 раза в неделю";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(27, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(242, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "Максимальная активность:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(27, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(190, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "Сильная активность:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(27, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(191, 20);
            this.label4.TabIndex = 24;
            this.label4.Text = "Средняя активность:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(121, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(262, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "отсутствие физической нагрузки";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label11.Location = new System.Drawing.Point(27, 145);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(211, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "Маленькая активность:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label12.Location = new System.Drawing.Point(27, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 20);
            this.label12.TabIndex = 21;
            this.label12.Text = "Сидячий:";
            // 
            // CloseInfo
            // 
            this.CloseInfo.Image = ((System.Drawing.Image)(resources.GetObject("CloseInfo.Image")));
            this.CloseInfo.Location = new System.Drawing.Point(524, 14);
            this.CloseInfo.Name = "CloseInfo";
            this.CloseInfo.Size = new System.Drawing.Size(15, 15);
            this.CloseInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CloseInfo.TabIndex = 20;
            this.CloseInfo.TabStop = false;
            this.CloseInfo.Click += new System.EventHandler(this.CloseInfo_Click);
            // 
            // Description
            // 
            this.Description.AutoSize = true;
            this.Description.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Description.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Description.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Description.Location = new System.Drawing.Point(48, 59);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(308, 20);
            this.Description.TabIndex = 7;
            this.Description.Text = "Это описание всех уровней активности";
            // 
            // ActivityLevels
            // 
            this.ActivityLevels.AutoSize = true;
            this.ActivityLevels.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ActivityLevels.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ActivityLevels.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ActivityLevels.Location = new System.Drawing.Point(183, 16);
            this.ActivityLevels.Name = "ActivityLevels";
            this.ActivityLevels.Size = new System.Drawing.Size(240, 29);
            this.ActivityLevels.TabIndex = 6;
            this.ActivityLevels.Text = "Уровни активности";
            // 
            // BMR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.InfoCheck);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.MaximumActivityResult);
            this.Controls.Add(this.StrongActivityResult);
            this.Controls.Add(this.AverageActivityResult);
            this.Controls.Add(this.SmallActivityResult);
            this.Controls.Add(this.SitResult);
            this.Controls.Add(this.MaximumActivity);
            this.Controls.Add(this.StrongActivity);
            this.Controls.Add(this.AverageActivity);
            this.Controls.Add(this.SmallActivity);
            this.Controls.Add(this.Sit);
            this.Controls.Add(this.YourBMR);
            this.Controls.Add(this.Expenses);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.Age);
            this.Controls.Add(this.nAge);
            this.Controls.Add(this.Female);
            this.Controls.Add(this.Male);
            this.Controls.Add(this.Kg);
            this.Controls.Add(this.Cm);
            this.Controls.Add(this.Weight1);
            this.Controls.Add(this.Height1);
            this.Controls.Add(this.nWeight);
            this.Controls.Add(this.nHeight);
            this.Controls.Add(this.nBMRCalculator);
            this.Controls.Add(this.back);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "BMR";
            this.Text = "BMR";
            this.Load += new System.EventHandler(this.BMR_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Female.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Female_pic)).EndInit();
            this.Male.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Male_pic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Info)).EndInit();
            this.InfoCheck.ResumeLayout(false);
            this.InfoCheck.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CloseInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label timer_to_begin;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button back;
        public System.Windows.Forms.Label nBMRCalculator;
        private System.Windows.Forms.Panel Female;
        private System.Windows.Forms.Label nFemale;
        private System.Windows.Forms.PictureBox Female_pic;
        private System.Windows.Forms.Panel Male;
        private System.Windows.Forms.Label nMale;
        private System.Windows.Forms.PictureBox Male_pic;
        private System.Windows.Forms.Label Kg;
        private System.Windows.Forms.Label Cm;
        private System.Windows.Forms.TextBox Weight1;
        private System.Windows.Forms.TextBox Height1;
        private System.Windows.Forms.Label nWeight;
        private System.Windows.Forms.Label nHeight;
        private System.Windows.Forms.TextBox Age;
        private System.Windows.Forms.Label nAge;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.PictureBox Info;
        public System.Windows.Forms.Label MaximumActivityResult;
        public System.Windows.Forms.Label StrongActivityResult;
        public System.Windows.Forms.Label AverageActivityResult;
        public System.Windows.Forms.Label SmallActivityResult;
        public System.Windows.Forms.Label SitResult;
        public System.Windows.Forms.Label MaximumActivity;
        public System.Windows.Forms.Label StrongActivity;
        public System.Windows.Forms.Label AverageActivity;
        public System.Windows.Forms.Label SmallActivity;
        public System.Windows.Forms.Label Sit;
        public System.Windows.Forms.Label YourBMR;
        public System.Windows.Forms.Label Expenses;
        private System.Windows.Forms.Panel InfoCheck;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox CloseInfo;
        private System.Windows.Forms.Label Description;
        private System.Windows.Forms.Label ActivityLevels;
    }
}