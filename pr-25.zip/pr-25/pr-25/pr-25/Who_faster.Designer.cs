﻿namespace pr_25
{
    partial class Faster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Faster));
            this.panel1 = new System.Windows.Forms.Panel();
            this.back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.timer_to_begin = new System.Windows.Forms.Label();
            this.How_long = new System.Windows.Forms.Label();
            this.Item = new System.Windows.Forms.Panel();
            this.ItemPhoto = new System.Windows.Forms.PictureBox();
            this.Info = new System.Windows.Forms.Label();
            this.Name1 = new System.Windows.Forms.Label();
            this.objects = new System.Windows.Forms.TabControl();
            this.speed = new System.Windows.Forms.TabPage();
            this.Horse = new System.Windows.Forms.Label();
            this.Slug = new System.Windows.Forms.Label();
            this.Horse_picture = new System.Windows.Forms.PictureBox();
            this.Slug_picture = new System.Windows.Forms.PictureBox();
            this.Jaguar = new System.Windows.Forms.Label();
            this.F1Car_picture = new System.Windows.Forms.PictureBox();
            this.Capybara = new System.Windows.Forms.Label();
            this.Jaguar_picture = new System.Windows.Forms.PictureBox();
            this.Sloth = new System.Windows.Forms.Label();
            this.Capybara_picture = new System.Windows.Forms.PictureBox();
            this.Worm = new System.Windows.Forms.Label();
            this.Sloth_picture = new System.Windows.Forms.PictureBox();
            this.F1Car = new System.Windows.Forms.Label();
            this.Worm_picture = new System.Windows.Forms.PictureBox();
            this.distance = new System.Windows.Forms.TabPage();
            this.Bus = new System.Windows.Forms.Label();
            this.Ronaldinho = new System.Windows.Forms.Label();
            this.FootballField = new System.Windows.Forms.Label();
            this.Havaianas = new System.Windows.Forms.Label();
            this.AirbusA380 = new System.Windows.Forms.Label();
            this.Havaianas_picture = new System.Windows.Forms.PictureBox();
            this.FootballField_picture = new System.Windows.Forms.PictureBox();
            this.Ronaldinho_picture = new System.Windows.Forms.PictureBox();
            this.Bus_picture = new System.Windows.Forms.PictureBox();
            this.AirbusA380_picture = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Item.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPhoto)).BeginInit();
            this.objects.SuspendLayout();
            this.speed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Horse_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Slug_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.F1Car_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Jaguar_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Capybara_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sloth_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Worm_picture)).BeginInit();
            this.distance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Havaianas_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FootballField_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ronaldinho_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bus_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AirbusA380_picture)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.back);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-35, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(959, 58);
            this.panel1.TabIndex = 1;
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(61, 20);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 26;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(155, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "MARATHON SKILLS 2016";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel2.Controls.Add(this.timer_to_begin);
            this.panel2.Location = new System.Drawing.Point(-35, 490);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(959, 42);
            this.panel2.TabIndex = 2;
            // 
            // timer_to_begin
            // 
            this.timer_to_begin.AutoSize = true;
            this.timer_to_begin.Location = new System.Drawing.Point(307, 15);
            this.timer_to_begin.Name = "timer_to_begin";
            this.timer_to_begin.Size = new System.Drawing.Size(269, 13);
            this.timer_to_begin.TabIndex = 0;
            this.timer_to_begin.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // How_long
            // 
            this.How_long.AutoSize = true;
            this.How_long.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.How_long.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.How_long.Location = new System.Drawing.Point(142, 60);
            this.How_long.Name = "How_long";
            this.How_long.Size = new System.Drawing.Size(348, 29);
            this.How_long.TabIndex = 6;
            this.How_long.Text = "Насколько долгий марафон?";
            // 
            // Item
            // 
            this.Item.Controls.Add(this.ItemPhoto);
            this.Item.Controls.Add(this.Info);
            this.Item.Controls.Add(this.Name1);
            this.Item.Location = new System.Drawing.Point(12, 92);
            this.Item.Name = "Item";
            this.Item.Size = new System.Drawing.Size(504, 392);
            this.Item.TabIndex = 24;
            this.Item.Visible = false;
            // 
            // ItemPhoto
            // 
            this.ItemPhoto.Location = new System.Drawing.Point(47, 50);
            this.ItemPhoto.Name = "ItemPhoto";
            this.ItemPhoto.Size = new System.Drawing.Size(238, 214);
            this.ItemPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ItemPhoto.TabIndex = 22;
            this.ItemPhoto.TabStop = false;
            // 
            // Info
            // 
            this.Info.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Info.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Info.Location = new System.Drawing.Point(43, 277);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(438, 93);
            this.Info.TabIndex = 9;
            this.Info.Text = "Информация";
            // 
            // Name1
            // 
            this.Name1.AutoSize = true;
            this.Name1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Name1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Name1.Location = new System.Drawing.Point(42, 19);
            this.Name1.Name = "Name1";
            this.Name1.Size = new System.Drawing.Size(69, 29);
            this.Name1.TabIndex = 8;
            this.Name1.Text = "Имя ";
            // 
            // objects
            // 
            this.objects.Controls.Add(this.speed);
            this.objects.Controls.Add(this.distance);
            this.objects.Location = new System.Drawing.Point(556, 60);
            this.objects.Name = "objects";
            this.objects.SelectedIndex = 0;
            this.objects.Size = new System.Drawing.Size(320, 424);
            this.objects.TabIndex = 25;
            // 
            // speed
            // 
            this.speed.Controls.Add(this.Horse);
            this.speed.Controls.Add(this.Slug);
            this.speed.Controls.Add(this.Horse_picture);
            this.speed.Controls.Add(this.Slug_picture);
            this.speed.Controls.Add(this.Jaguar);
            this.speed.Controls.Add(this.F1Car_picture);
            this.speed.Controls.Add(this.Capybara);
            this.speed.Controls.Add(this.Jaguar_picture);
            this.speed.Controls.Add(this.Sloth);
            this.speed.Controls.Add(this.Capybara_picture);
            this.speed.Controls.Add(this.Worm);
            this.speed.Controls.Add(this.Sloth_picture);
            this.speed.Controls.Add(this.F1Car);
            this.speed.Controls.Add(this.Worm_picture);
            this.speed.Location = new System.Drawing.Point(4, 22);
            this.speed.Name = "speed";
            this.speed.Padding = new System.Windows.Forms.Padding(3);
            this.speed.Size = new System.Drawing.Size(312, 398);
            this.speed.TabIndex = 0;
            this.speed.Text = "Скорость";
            this.speed.UseVisualStyleBackColor = true;
            // 
            // Horse
            // 
            this.Horse.AutoSize = true;
            this.Horse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Horse.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Horse.Location = new System.Drawing.Point(255, 168);
            this.Horse.Name = "Horse";
            this.Horse.Size = new System.Drawing.Size(52, 20);
            this.Horse.TabIndex = 63;
            this.Horse.Text = "Horse";
            // 
            // Slug
            // 
            this.Slug.AutoSize = true;
            this.Slug.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Slug.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Slug.Location = new System.Drawing.Point(89, 334);
            this.Slug.Name = "Slug";
            this.Slug.Size = new System.Drawing.Size(41, 20);
            this.Slug.TabIndex = 62;
            this.Slug.Text = "Slug";
            // 
            // Horse_picture
            // 
            this.Horse_picture.Image = ((System.Drawing.Image)(resources.GetObject("Horse_picture.Image")));
            this.Horse_picture.Location = new System.Drawing.Point(172, 165);
            this.Horse_picture.Name = "Horse_picture";
            this.Horse_picture.Size = new System.Drawing.Size(80, 50);
            this.Horse_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Horse_picture.TabIndex = 61;
            this.Horse_picture.TabStop = false;
            this.Horse_picture.Click += new System.EventHandler(this.Horse_picture_Click);
            // 
            // Slug_picture
            // 
            this.Slug_picture.Image = ((System.Drawing.Image)(resources.GetObject("Slug_picture.Image")));
            this.Slug_picture.Location = new System.Drawing.Point(6, 339);
            this.Slug_picture.Name = "Slug_picture";
            this.Slug_picture.Size = new System.Drawing.Size(80, 50);
            this.Slug_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Slug_picture.TabIndex = 60;
            this.Slug_picture.TabStop = false;
            this.Slug_picture.Click += new System.EventHandler(this.Slug_picture_Click);
            // 
            // Jaguar
            // 
            this.Jaguar.AutoSize = true;
            this.Jaguar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Jaguar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Jaguar.Location = new System.Drawing.Point(89, 269);
            this.Jaguar.Name = "Jaguar";
            this.Jaguar.Size = new System.Drawing.Size(58, 20);
            this.Jaguar.TabIndex = 59;
            this.Jaguar.Text = "Jaguar";
            // 
            // F1Car_picture
            // 
            this.F1Car_picture.Image = ((System.Drawing.Image)(resources.GetObject("F1Car_picture.Image")));
            this.F1Car_picture.Location = new System.Drawing.Point(6, 9);
            this.F1Car_picture.Name = "F1Car_picture";
            this.F1Car_picture.Size = new System.Drawing.Size(80, 50);
            this.F1Car_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.F1Car_picture.TabIndex = 51;
            this.F1Car_picture.TabStop = false;
            this.F1Car_picture.Click += new System.EventHandler(this.F1Car_picture_Click);
            // 
            // Capybara
            // 
            this.Capybara.AutoSize = true;
            this.Capybara.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Capybara.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Capybara.Location = new System.Drawing.Point(89, 206);
            this.Capybara.Name = "Capybara";
            this.Capybara.Size = new System.Drawing.Size(77, 20);
            this.Capybara.TabIndex = 58;
            this.Capybara.Text = "Capybara";
            // 
            // Jaguar_picture
            // 
            this.Jaguar_picture.Image = ((System.Drawing.Image)(resources.GetObject("Jaguar_picture.Image")));
            this.Jaguar_picture.Location = new System.Drawing.Point(6, 273);
            this.Jaguar_picture.Name = "Jaguar_picture";
            this.Jaguar_picture.Size = new System.Drawing.Size(80, 50);
            this.Jaguar_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Jaguar_picture.TabIndex = 52;
            this.Jaguar_picture.TabStop = false;
            this.Jaguar_picture.Click += new System.EventHandler(this.Jaguar_picture_Click);
            // 
            // Sloth
            // 
            this.Sloth.AutoSize = true;
            this.Sloth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Sloth.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Sloth.Location = new System.Drawing.Point(89, 142);
            this.Sloth.Name = "Sloth";
            this.Sloth.Size = new System.Drawing.Size(46, 20);
            this.Sloth.TabIndex = 57;
            this.Sloth.Text = "Sloth";
            // 
            // Capybara_picture
            // 
            this.Capybara_picture.Image = ((System.Drawing.Image)(resources.GetObject("Capybara_picture.Image")));
            this.Capybara_picture.Location = new System.Drawing.Point(6, 207);
            this.Capybara_picture.Name = "Capybara_picture";
            this.Capybara_picture.Size = new System.Drawing.Size(80, 50);
            this.Capybara_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Capybara_picture.TabIndex = 53;
            this.Capybara_picture.TabStop = false;
            this.Capybara_picture.Click += new System.EventHandler(this.Capybara_picture_Click);
            // 
            // Worm
            // 
            this.Worm.AutoSize = true;
            this.Worm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Worm.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Worm.Location = new System.Drawing.Point(89, 75);
            this.Worm.Name = "Worm";
            this.Worm.Size = new System.Drawing.Size(51, 20);
            this.Worm.TabIndex = 56;
            this.Worm.Text = "Worm";
            // 
            // Sloth_picture
            // 
            this.Sloth_picture.Image = ((System.Drawing.Image)(resources.GetObject("Sloth_picture.Image")));
            this.Sloth_picture.InitialImage = null;
            this.Sloth_picture.Location = new System.Drawing.Point(6, 141);
            this.Sloth_picture.Name = "Sloth_picture";
            this.Sloth_picture.Size = new System.Drawing.Size(80, 50);
            this.Sloth_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Sloth_picture.TabIndex = 54;
            this.Sloth_picture.TabStop = false;
            this.Sloth_picture.Click += new System.EventHandler(this.Sloth_picture_Click);
            // 
            // F1Car
            // 
            this.F1Car.AutoSize = true;
            this.F1Car.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.F1Car.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.F1Car.Location = new System.Drawing.Point(89, 12);
            this.F1Car.Name = "F1Car";
            this.F1Car.Size = new System.Drawing.Size(57, 20);
            this.F1Car.TabIndex = 50;
            this.F1Car.Text = "F1 Car";
            // 
            // Worm_picture
            // 
            this.Worm_picture.Image = ((System.Drawing.Image)(resources.GetObject("Worm_picture.Image")));
            this.Worm_picture.Location = new System.Drawing.Point(6, 75);
            this.Worm_picture.Name = "Worm_picture";
            this.Worm_picture.Size = new System.Drawing.Size(80, 50);
            this.Worm_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Worm_picture.TabIndex = 55;
            this.Worm_picture.TabStop = false;
            this.Worm_picture.Click += new System.EventHandler(this.Worm_picture_Click);
            // 
            // distance
            // 
            this.distance.Controls.Add(this.Bus);
            this.distance.Controls.Add(this.Ronaldinho);
            this.distance.Controls.Add(this.FootballField);
            this.distance.Controls.Add(this.Havaianas);
            this.distance.Controls.Add(this.AirbusA380);
            this.distance.Controls.Add(this.Havaianas_picture);
            this.distance.Controls.Add(this.FootballField_picture);
            this.distance.Controls.Add(this.Ronaldinho_picture);
            this.distance.Controls.Add(this.Bus_picture);
            this.distance.Controls.Add(this.AirbusA380_picture);
            this.distance.Location = new System.Drawing.Point(4, 22);
            this.distance.Name = "distance";
            this.distance.Padding = new System.Windows.Forms.Padding(3);
            this.distance.Size = new System.Drawing.Size(312, 398);
            this.distance.TabIndex = 1;
            this.distance.Text = "Дистанция";
            this.distance.UseVisualStyleBackColor = true;
            // 
            // Bus
            // 
            this.Bus.AutoSize = true;
            this.Bus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Bus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Bus.Location = new System.Drawing.Point(145, 359);
            this.Bus.Name = "Bus";
            this.Bus.Size = new System.Drawing.Size(37, 20);
            this.Bus.TabIndex = 31;
            this.Bus.Text = "Bus";
            // 
            // Ronaldinho
            // 
            this.Ronaldinho.AutoSize = true;
            this.Ronaldinho.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Ronaldinho.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Ronaldinho.Location = new System.Drawing.Point(145, 275);
            this.Ronaldinho.Name = "Ronaldinho";
            this.Ronaldinho.Size = new System.Drawing.Size(90, 20);
            this.Ronaldinho.TabIndex = 30;
            this.Ronaldinho.Text = "Ronaldinho";
            // 
            // FootballField
            // 
            this.FootballField.AutoSize = true;
            this.FootballField.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FootballField.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.FootballField.Location = new System.Drawing.Point(145, 203);
            this.FootballField.Name = "FootballField";
            this.FootballField.Size = new System.Drawing.Size(104, 20);
            this.FootballField.TabIndex = 29;
            this.FootballField.Text = "Football Field";
            // 
            // Havaianas
            // 
            this.Havaianas.AutoSize = true;
            this.Havaianas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Havaianas.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Havaianas.Location = new System.Drawing.Point(145, 119);
            this.Havaianas.Name = "Havaianas";
            this.Havaianas.Size = new System.Drawing.Size(133, 20);
            this.Havaianas.TabIndex = 28;
            this.Havaianas.Text = "Pair of Havaianas";
            // 
            // AirbusA380
            // 
            this.AirbusA380.AutoSize = true;
            this.AirbusA380.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AirbusA380.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.AirbusA380.Location = new System.Drawing.Point(145, 41);
            this.AirbusA380.Name = "AirbusA380";
            this.AirbusA380.Size = new System.Drawing.Size(96, 20);
            this.AirbusA380.TabIndex = 22;
            this.AirbusA380.Text = "Airbus A380";
            // 
            // Havaianas_picture
            // 
            this.Havaianas_picture.Image = ((System.Drawing.Image)(resources.GetObject("Havaianas_picture.Image")));
            this.Havaianas_picture.Location = new System.Drawing.Point(34, 92);
            this.Havaianas_picture.Name = "Havaianas_picture";
            this.Havaianas_picture.Size = new System.Drawing.Size(98, 65);
            this.Havaianas_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Havaianas_picture.TabIndex = 27;
            this.Havaianas_picture.TabStop = false;
            this.Havaianas_picture.Click += new System.EventHandler(this.Havaianas_picture_Click);
            // 
            // FootballField_picture
            // 
            this.FootballField_picture.Image = ((System.Drawing.Image)(resources.GetObject("FootballField_picture.Image")));
            this.FootballField_picture.Location = new System.Drawing.Point(34, 171);
            this.FootballField_picture.Name = "FootballField_picture";
            this.FootballField_picture.Size = new System.Drawing.Size(98, 65);
            this.FootballField_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.FootballField_picture.TabIndex = 26;
            this.FootballField_picture.TabStop = false;
            this.FootballField_picture.Click += new System.EventHandler(this.FootballField_picture_Click);
            // 
            // Ronaldinho_picture
            // 
            this.Ronaldinho_picture.Image = ((System.Drawing.Image)(resources.GetObject("Ronaldinho_picture.Image")));
            this.Ronaldinho_picture.Location = new System.Drawing.Point(34, 251);
            this.Ronaldinho_picture.Name = "Ronaldinho_picture";
            this.Ronaldinho_picture.Size = new System.Drawing.Size(98, 65);
            this.Ronaldinho_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Ronaldinho_picture.TabIndex = 25;
            this.Ronaldinho_picture.TabStop = false;
            this.Ronaldinho_picture.Click += new System.EventHandler(this.Ronaldinho_picture_Click);
            // 
            // Bus_picture
            // 
            this.Bus_picture.Image = ((System.Drawing.Image)(resources.GetObject("Bus_picture.Image")));
            this.Bus_picture.Location = new System.Drawing.Point(34, 328);
            this.Bus_picture.Name = "Bus_picture";
            this.Bus_picture.Size = new System.Drawing.Size(98, 65);
            this.Bus_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Bus_picture.TabIndex = 24;
            this.Bus_picture.TabStop = false;
            this.Bus_picture.Click += new System.EventHandler(this.Bus_picture_Click);
            // 
            // AirbusA380_picture
            // 
            this.AirbusA380_picture.Image = ((System.Drawing.Image)(resources.GetObject("AirbusA380_picture.Image")));
            this.AirbusA380_picture.Location = new System.Drawing.Point(34, 10);
            this.AirbusA380_picture.Name = "AirbusA380_picture";
            this.AirbusA380_picture.Size = new System.Drawing.Size(98, 65);
            this.AirbusA380_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AirbusA380_picture.TabIndex = 23;
            this.AirbusA380_picture.TabStop = false;
            this.AirbusA380_picture.Click += new System.EventHandler(this.AirbusA380_picture_Click);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Faster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.objects);
            this.Controls.Add(this.Item);
            this.Controls.Add(this.How_long);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Faster";
            this.Load += new System.EventHandler(this.Who_faster_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Item.ResumeLayout(false);
            this.Item.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemPhoto)).EndInit();
            this.objects.ResumeLayout(false);
            this.speed.ResumeLayout(false);
            this.speed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Horse_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Slug_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.F1Car_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Jaguar_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Capybara_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sloth_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Worm_picture)).EndInit();
            this.distance.ResumeLayout(false);
            this.distance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Havaianas_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FootballField_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ronaldinho_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bus_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AirbusA380_picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label timer_to_begin;
        public System.Windows.Forms.Label How_long;
        private System.Windows.Forms.Panel Item;
        private System.Windows.Forms.PictureBox ItemPhoto;
        public System.Windows.Forms.Label Info;
        public System.Windows.Forms.Label Name1;
        private System.Windows.Forms.TabControl objects;
        private System.Windows.Forms.TabPage speed;
        private System.Windows.Forms.TabPage distance;
        private System.Windows.Forms.Timer timer;
        public System.Windows.Forms.Label Horse;
        public System.Windows.Forms.Label Slug;
        private System.Windows.Forms.PictureBox Horse_picture;
        private System.Windows.Forms.PictureBox Slug_picture;
        public System.Windows.Forms.Label Jaguar;
        private System.Windows.Forms.PictureBox F1Car_picture;
        public System.Windows.Forms.Label Capybara;
        private System.Windows.Forms.PictureBox Jaguar_picture;
        public System.Windows.Forms.Label Sloth;
        private System.Windows.Forms.PictureBox Capybara_picture;
        public System.Windows.Forms.Label Worm;
        private System.Windows.Forms.PictureBox Sloth_picture;
        public System.Windows.Forms.Label F1Car;
        private System.Windows.Forms.PictureBox Worm_picture;
        public System.Windows.Forms.Label Bus;
        public System.Windows.Forms.Label Ronaldinho;
        public System.Windows.Forms.Label FootballField;
        public System.Windows.Forms.Label Havaianas;
        public System.Windows.Forms.Label AirbusA380;
        private System.Windows.Forms.PictureBox Havaianas_picture;
        private System.Windows.Forms.PictureBox FootballField_picture;
        private System.Windows.Forms.PictureBox Ronaldinho_picture;
        private System.Windows.Forms.PictureBox Bus_picture;
        private System.Windows.Forms.PictureBox AirbusA380_picture;
        private System.Windows.Forms.Button back;
    }
}