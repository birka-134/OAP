﻿namespace pr_25
{
    partial class intMap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(intMap));
			this.label1 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.map = new System.Windows.Forms.PictureBox();
			this.ch1 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.map)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label1.ForeColor = System.Drawing.SystemColors.Control;
			this.label1.Location = new System.Drawing.Point(69, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(559, 29);
			this.label1.TabIndex = 0;
			this.label1.Text = "Интерактивная карта MARATHON SKILLS 2016";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(-35, -1);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(959, 58);
			this.panel1.TabIndex = 1;
			// 
			// map
			// 
			this.map.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("map.BackgroundImage")));
			this.map.Location = new System.Drawing.Point(12, 63);
			this.map.Name = "map";
			this.map.Size = new System.Drawing.Size(516, 455);
			this.map.TabIndex = 2;
			this.map.TabStop = false;
			// 
			// ch1
			// 
			this.ch1.BackColor = System.Drawing.Color.Transparent;
			this.ch1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.ch1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.ch1.Location = new System.Drawing.Point(297, 79);
			this.ch1.Name = "ch1";
			this.ch1.Size = new System.Drawing.Size(40, 40);
			this.ch1.TabIndex = 3;
			this.ch1.UseVisualStyleBackColor = false;
			this.ch1.Click += new System.EventHandler(this.ch1_Click);
			// 
			// intMap
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(888, 532);
			this.Controls.Add(this.ch1);
			this.Controls.Add(this.map);
			this.Controls.Add(this.panel1);
			this.Name = "intMap";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.map)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox map;
		private System.Windows.Forms.Button ch1;
	}
}