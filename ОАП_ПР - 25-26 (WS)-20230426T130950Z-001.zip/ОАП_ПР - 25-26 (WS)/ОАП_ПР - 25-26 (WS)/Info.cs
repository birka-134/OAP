﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ОАП_ПР___25_26__WS_
{
    public partial class Info : Form
    {
        public Info()
        {
            InitializeComponent();
        }

        public DateTime endDate;
        private void Info_Load(object sender, EventArgs e)
        {
            RoundedButton.RoundButton(btn_Back, 10);

            StreamReader fileIn = new StreamReader("marathon-skills-2016-marathon-info.txt", Encoding.GetEncoding(1251));
            string str = fileIn.ReadToEnd();
            l_Info.Text = str;
            fileIn.Close();

            endDate = new DateTime(2022, 5, 11, 8, 30, 0);
            timer.Start();
        }

        private void pb_InteractMap_Click(object sender, EventArgs e)
        {
            Map Form2 = new Map();
            this.Hide();
            Form2.ShowDialog();
            this.Show();
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            l_Count.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", endDate - DateTime.Now);
        }
    }
}
