﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОАП_ПР___25_26__WS_
{
	public partial class BMR : Form
	{
		public BMR()
		{
			InitializeComponent();
		}

		public DateTime endDate;
		private void btn_Back_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		public bool male = false, female = false;

		private void pb_Male_Click(object sender, EventArgs e)
		{
			pnl_Male.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			pnl_Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
			male = true;
			female = false;
		}

		private void pb_Female_Click(object sender, EventArgs e)
		{
			pnl_Female.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			pnl_Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
			male = false;
			female = true;
		}

		private void btn_Calculate_Click(object sender, EventArgs e)
		{
			double bmr=0;
			if(male)
			{
				bmr = 88.36 + 13.4 * Convert.ToInt32(tb_Weight.Text) + 4.8 * Convert.ToInt32(tb_Height.Text) - 5.7 * Convert.ToInt32(tb_Age.Text);
			}
			else if(female)
			{
				bmr = 447.6 + 9.2 * Convert.ToInt32(tb_Weight.Text) + 3.1 * Convert.ToInt32(tb_Height.Text) - 4.3 * Convert.ToInt32(tb_Age.Text);
			}

			l_SitResult.Text = Convert.ToString(bmr * 1.2);
			l_SmallActivityResult.Text = Convert.ToString(bmr * 1.375);
			l_AverageActivityResult.Text = Convert.ToString(bmr * 1.55);
			l_StrongActivityResult.Text = Convert.ToString(bmr * 1.725);
			l_MaximumActivityResult.Text = Convert.ToString(bmr * 1.9);
		}

		private void pb_Information_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = true;
		}

		private void pb_CloseInfo_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = false;
		}

        private void BMR_Load(object sender, EventArgs e)
		{
			RoundedButton.RoundButton(btn_Calculate, 10);
			RoundedButton.RoundButton(btn_Cancel, 10);
			RoundedButton.RoundButton(btn_Back, 10);
			pnl_InfoCheckpoint.Visible = false;

			endDate = new DateTime(2022, 5, 11, 8, 30, 0);
			timer.Start();
		}

        private void timer_Tick(object sender, EventArgs e)
        {
			l_Count.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", endDate - DateTime.Now);
		}

        private void btn_Cancel_Click(object sender, EventArgs e)
		{
			tb_Height.Text = "";
			tb_Weight.Text = "";
			tb_Age.Text = "";
			pnl_Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
			pnl_Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
			male = false;
			female = false;

			l_SitResult.Text = "0";
			l_SmallActivityResult.Text = "0";
			l_AverageActivityResult.Text = "0";
			l_StrongActivityResult.Text = "0";
			l_MaximumActivityResult.Text = "0";
		}
	}
}
