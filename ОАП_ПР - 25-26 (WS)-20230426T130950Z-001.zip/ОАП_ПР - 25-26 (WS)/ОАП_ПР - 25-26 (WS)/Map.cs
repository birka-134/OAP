﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОАП_ПР___25_26__WS_
{
	public partial class Map : Form
	{
		public Map()
		{
			InitializeComponent();
		}

		private void btn_Back_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		public DateTime endDate;

		private void Map_Load(object sender, EventArgs e)
		{
			RoundedButton.RoundButton(btn_Back, 10);
			RoundedButton.RoundButton(btn_Full, 10);
			RoundedButton.RoundButton(btn_Half, 10);
			RoundedButton.RoundButton(btn_Fun, 10);

			RoundedButton.RoundButton(btn_Check1, 30);
			RoundedButton.RoundButton(btn_Check2, 30); 
			RoundedButton.RoundButton(btn_Check3, 30);
			RoundedButton.RoundButton(btn_Check4, 30); 
			RoundedButton.RoundButton(btn_Check5, 30);
			RoundedButton.RoundButton(btn_Check6, 30);

			pnl_InfoCheckpoint.Visible = false;
			pb_Drinks.Visible = false;
			pb_EnergyBars.Visible = false;
			pb_Toilets.Visible = false;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;

			endDate = new DateTime(2022, 5, 11, 8, 30, 0);
			timer.Start();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Checkpoint 1";
			l_Features.Text = "Стенд питья \n\nЭнергетические батончики";
			pb_Drinks.Visible = true;
			pb_EnergyBars.Visible = true;
			pb_Toilets.Visible = false;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Checkpoint 2";
			l_Features.Text = " Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Информационный центр \n\n Медицинский пункт";
			pb_Drinks.Visible = true;
			pb_EnergyBars.Visible = true;
			pb_Toilets.Visible = true;
			pb_Information.Visible = true;
			pb_Medical.Visible = true;
			pb_Medical.Location = new Point(16, 174);
		}

        private void button3_Click(object sender, EventArgs e)
        {
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Checkpoint 3";
			l_Features.Text = " Стенд питья \n\n Энергетические батончики \n\n Туалет ";
			pb_Drinks.Visible = true;
			pb_EnergyBars.Visible = true;
			pb_Toilets.Visible = true;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;
		}

        private void button4_Click(object sender, EventArgs e)
        {
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Checkpoint 4";
			l_Features.Text = " Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Медицинский пункт";
			pb_Drinks.Visible = true;
			pb_EnergyBars.Visible = true;
			pb_Toilets.Visible = true;
			pb_Information.Visible = false;
			pb_Medical.Visible = true;
			pb_Medical.Location = new Point(16, 143);

		}

        private void button5_Click(object sender, EventArgs e)
        {
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Checkpoint 5";
			l_Features.Text = " Стенд питья \n\n Энергетические батончики \n\n Туалет \n\n Информационный центр ";
			pb_Drinks.Visible = true;
			pb_EnergyBars.Visible = true;
			pb_Toilets.Visible = true;
			pb_Information.Visible = true;
			pb_Medical.Visible = false;
		}

        private void button6_Click(object sender, EventArgs e)
        {
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Checkpoint 6";
			l_Features.Text = " Стенд питья \n\n Энергетические батончики \n\n Туалет ";
			pb_Drinks.Visible = true;
			pb_EnergyBars.Visible = true;
			pb_Toilets.Visible = true;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;
		}

		private void button7_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Race Start";
			l_Features.Text = "Full Marathon";
			pb_Drinks.Visible = false;
			pb_EnergyBars.Visible = false;
			pb_Toilets.Visible = false;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;
		}

		private void button9_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Race Start";
			l_Features.Text = "Half Marathon";
			pb_Drinks.Visible = false;
			pb_EnergyBars.Visible = false;
			pb_Toilets.Visible = false;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;
		}

		private void button8_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = true;
			l_Checkpoint.Text = "Race Start";
			l_Features.Text = "Fun Run";
			pb_Drinks.Visible = false;
			pb_EnergyBars.Visible = false;
			pb_Toilets.Visible = false;
			pb_Information.Visible = false;
			pb_Medical.Visible = false;
		}

		private void pb_CloseInfo_Click(object sender, EventArgs e)
		{
			pnl_InfoCheckpoint.Visible = false;
		}

        private void timer_Tick(object sender, EventArgs e)
        {
			l_Count.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", endDate - DateTime.Now);
		}
    }
}
