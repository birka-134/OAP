﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОАП_ПР___25_26__WS_
{
	public partial class BMI : Form
	{
		public BMI()
		{
			InitializeComponent();
		}

		public DateTime endDate;
		private void btn_Back_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void btn_Cancel_Click(object sender, EventArgs e)
		{
			tb_Height.Text = "";
			tb_Weight.Text = "";
			pnl_Result.Visible = false;
			l_BMI.Visible = false;
			pnl_Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
			pnl_Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
			trb_BMI.Value = 0;
		}

		private void BMI_Load(object sender, EventArgs e)
		{
			RoundedButton.RoundButton(btn_Calculate, 10);
			RoundedButton.RoundButton(btn_Cancel, 10);
			RoundedButton.RoundButton(btn_Back, 10);
			pnl_Result.Visible = false;
			l_BMI.Visible = false;

			endDate = new DateTime(2022, 5, 11, 8, 30, 0);
			timer.Start();
		}

		private void btn_Calculate_Click(object sender, EventArgs e)
		{
			//Рассчет
			pnl_Result.Visible = true;
			double Weight = Convert.ToDouble(tb_Weight.Text);
			double Height = Convert.ToDouble(tb_Height.Text);
			Height = Height / 100;
			//Результат
			double bmi = Weight / (Height * Height);
			if (bmi < 18.5)
			{
				pb_Result1.Visible = true;
				pb_Result2.Visible = false;
				pb_Result3.Visible = false;
				pb_Result4.Visible = false;
				l_Result.Text = "Недостаточный вес";
			}
			else if (bmi >= 18.5 && bmi <= 24.9)
			{
				pb_Result1.Visible = false;
				pb_Result2.Visible = true;
				pb_Result3.Visible = false;
				pb_Result4.Visible = false;
				l_Result.Text = "Здоровый вес";
			}
			else if (bmi>=25 && bmi<= 29.9)
			{
				pb_Result1.Visible = false;
				pb_Result2.Visible = false;
				pb_Result3.Visible = true;
				pb_Result4.Visible = false;
				l_Result.Text = "Избыточный вес";
			}
			else if (bmi >= 30)
			{
				pb_Result1.Visible = false;
				pb_Result2.Visible = false;
				pb_Result3.Visible = false;
				pb_Result4.Visible = true;
				l_Result.Text = "Ожирение";
			}
			//Изменение полосы
			l_BMI.Text = Convert.ToString(Math.Round(bmi, 1));

			if (bmi <= 10)
			{
				trb_BMI.Value = 10;
				l_BMI.Location = new Point(475, l_BMI.Location.Y);
			}
			else if (bmi >= 40)
			{
				trb_BMI.Value = 40;
				l_BMI.Location = new Point(820, l_BMI.Location.Y);
			}
			else
			{
				trb_BMI.Value = Convert.ToInt32(bmi); 
				l_BMI.Location = new Point(Convert.ToInt32(375 + bmi*11.5), l_BMI.Location.Y);

			}
			l_BMI.Visible = true;
		}

		private void pb_Male_Click(object sender, EventArgs e)
		{
			pnl_Male.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			pnl_Female.BorderStyle = System.Windows.Forms.BorderStyle.None;
		}

		private void pb_Female_Click(object sender, EventArgs e)
		{
			pnl_Female.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			pnl_Male.BorderStyle = System.Windows.Forms.BorderStyle.None;
		}

        private void timer_Tick(object sender, EventArgs e)
        {
			l_Count.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", endDate - DateTime.Now);
		}
    }
}
