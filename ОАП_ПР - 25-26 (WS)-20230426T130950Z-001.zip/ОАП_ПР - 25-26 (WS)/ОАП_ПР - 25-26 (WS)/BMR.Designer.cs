﻿
namespace ОАП_ПР___25_26__WS_
{
    partial class BMR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BMR));
            this.l_BMRCalculator = new System.Windows.Forms.Label();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_Calculate = new System.Windows.Forms.Button();
            this.l_Kg = new System.Windows.Forms.Label();
            this.l_Cm = new System.Windows.Forms.Label();
            this.tb_Weight = new System.Windows.Forms.TextBox();
            this.tb_Height = new System.Windows.Forms.TextBox();
            this.l_Weight = new System.Windows.Forms.Label();
            this.l_Height = new System.Windows.Forms.Label();
            this.tb_Age = new System.Windows.Forms.TextBox();
            this.l_Age = new System.Windows.Forms.Label();
            this.pnl_Down = new System.Windows.Forms.Panel();
            this.l_Count = new System.Windows.Forms.Label();
            this.pnl_Up = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.l_MarathonSkills = new System.Windows.Forms.Label();
            this.pnl_Female = new System.Windows.Forms.Panel();
            this.l_Female = new System.Windows.Forms.Label();
            this.pb_Female = new System.Windows.Forms.PictureBox();
            this.pnl_Male = new System.Windows.Forms.Panel();
            this.l_Male = new System.Windows.Forms.Label();
            this.pb_Male = new System.Windows.Forms.PictureBox();
            this.l_Expenses = new System.Windows.Forms.Label();
            this.l_YourBMR = new System.Windows.Forms.Label();
            this.l_Sit = new System.Windows.Forms.Label();
            this.l_AverageActivity = new System.Windows.Forms.Label();
            this.l_StrongActivity = new System.Windows.Forms.Label();
            this.l_MaximumActivity = new System.Windows.Forms.Label();
            this.l_SitResult = new System.Windows.Forms.Label();
            this.l_SmallActivity = new System.Windows.Forms.Label();
            this.l_SmallActivityResult = new System.Windows.Forms.Label();
            this.l_AverageActivityResult = new System.Windows.Forms.Label();
            this.l_StrongActivityResult = new System.Windows.Forms.Label();
            this.l_MaximumActivityResult = new System.Windows.Forms.Label();
            this.pb_Information = new System.Windows.Forms.PictureBox();
            this.pnl_InfoCheckpoint = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pb_CloseInfo = new System.Windows.Forms.PictureBox();
            this.l_ThisDescription = new System.Windows.Forms.Label();
            this.l_LevelsActivity = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pnl_Down.SuspendLayout();
            this.pnl_Up.SuspendLayout();
            this.pnl_Female.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Female)).BeginInit();
            this.pnl_Male.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Male)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Information)).BeginInit();
            this.pnl_InfoCheckpoint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_CloseInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // l_BMRCalculator
            // 
            this.l_BMRCalculator.AutoSize = true;
            this.l_BMRCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_BMRCalculator.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_BMRCalculator.Location = new System.Drawing.Point(329, 78);
            this.l_BMRCalculator.Name = "l_BMRCalculator";
            this.l_BMRCalculator.Size = new System.Drawing.Size(217, 29);
            this.l_BMRCalculator.TabIndex = 11;
            this.l_BMRCalculator.Text = "BMR калькулятор";
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Cancel.FlatAppearance.BorderSize = 0;
            this.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Cancel.Location = new System.Drawing.Point(196, 525);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 26;
            this.btn_Cancel.Text = "Отмена";
            this.btn_Cancel.UseVisualStyleBackColor = false;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // btn_Calculate
            // 
            this.btn_Calculate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Calculate.FlatAppearance.BorderSize = 0;
            this.btn_Calculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Calculate.Location = new System.Drawing.Point(70, 525);
            this.btn_Calculate.Name = "btn_Calculate";
            this.btn_Calculate.Size = new System.Drawing.Size(98, 23);
            this.btn_Calculate.TabIndex = 25;
            this.btn_Calculate.Text = "Рассчитать";
            this.btn_Calculate.UseVisualStyleBackColor = false;
            this.btn_Calculate.Click += new System.EventHandler(this.btn_Calculate_Click);
            // 
            // l_Kg
            // 
            this.l_Kg.AutoSize = true;
            this.l_Kg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Kg.Location = new System.Drawing.Point(223, 445);
            this.l_Kg.Name = "l_Kg";
            this.l_Kg.Size = new System.Drawing.Size(21, 16);
            this.l_Kg.TabIndex = 24;
            this.l_Kg.Text = "кг";
            // 
            // l_Cm
            // 
            this.l_Cm.AutoSize = true;
            this.l_Cm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Cm.Location = new System.Drawing.Point(223, 409);
            this.l_Cm.Name = "l_Cm";
            this.l_Cm.Size = new System.Drawing.Size(24, 16);
            this.l_Cm.TabIndex = 23;
            this.l_Cm.Text = "см";
            // 
            // tb_Weight
            // 
            this.tb_Weight.Location = new System.Drawing.Point(149, 441);
            this.tb_Weight.Name = "tb_Weight";
            this.tb_Weight.Size = new System.Drawing.Size(68, 20);
            this.tb_Weight.TabIndex = 22;
            // 
            // tb_Height
            // 
            this.tb_Height.Location = new System.Drawing.Point(149, 405);
            this.tb_Height.Name = "tb_Height";
            this.tb_Height.Size = new System.Drawing.Size(68, 20);
            this.tb_Height.TabIndex = 21;
            // 
            // l_Weight
            // 
            this.l_Weight.AutoSize = true;
            this.l_Weight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Weight.Location = new System.Drawing.Point(108, 445);
            this.l_Weight.Name = "l_Weight";
            this.l_Weight.Size = new System.Drawing.Size(35, 16);
            this.l_Weight.TabIndex = 20;
            this.l_Weight.Text = "Вес:";
            // 
            // l_Height
            // 
            this.l_Height.AutoSize = true;
            this.l_Height.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Height.Location = new System.Drawing.Point(101, 409);
            this.l_Height.Name = "l_Height";
            this.l_Height.Size = new System.Drawing.Size(42, 16);
            this.l_Height.TabIndex = 19;
            this.l_Height.Text = "Рост:";
            // 
            // tb_Age
            // 
            this.tb_Age.Location = new System.Drawing.Point(149, 477);
            this.tb_Age.Name = "tb_Age";
            this.tb_Age.Size = new System.Drawing.Size(68, 20);
            this.tb_Age.TabIndex = 28;
            // 
            // l_Age
            // 
            this.l_Age.AutoSize = true;
            this.l_Age.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Age.Location = new System.Drawing.Point(77, 481);
            this.l_Age.Name = "l_Age";
            this.l_Age.Size = new System.Drawing.Size(66, 16);
            this.l_Age.TabIndex = 27;
            this.l_Age.Text = "Возраст:";
            // 
            // pnl_Down
            // 
            this.pnl_Down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Down.Controls.Add(this.l_Count);
            this.pnl_Down.Location = new System.Drawing.Point(-1, 624);
            this.pnl_Down.Name = "pnl_Down";
            this.pnl_Down.Size = new System.Drawing.Size(886, 39);
            this.pnl_Down.TabIndex = 30;
            // 
            // l_Count
            // 
            this.l_Count.AutoSize = true;
            this.l_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Count.ForeColor = System.Drawing.SystemColors.Window;
            this.l_Count.Location = new System.Drawing.Point(306, 12);
            this.l_Count.Name = "l_Count";
            this.l_Count.Size = new System.Drawing.Size(340, 16);
            this.l_Count.TabIndex = 1;
            this.l_Count.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // pnl_Up
            // 
            this.pnl_Up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Up.Controls.Add(this.btn_Back);
            this.pnl_Up.Controls.Add(this.l_MarathonSkills);
            this.pnl_Up.Location = new System.Drawing.Point(-1, -3);
            this.pnl_Up.Name = "pnl_Up";
            this.pnl_Up.Size = new System.Drawing.Size(886, 60);
            this.pnl_Up.TabIndex = 29;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Back.FlatAppearance.BorderSize = 0;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Back.Location = new System.Drawing.Point(30, 22);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Назад";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // l_MarathonSkills
            // 
            this.l_MarathonSkills.AutoSize = true;
            this.l_MarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MarathonSkills.ForeColor = System.Drawing.SystemColors.Window;
            this.l_MarathonSkills.Location = new System.Drawing.Point(135, 14);
            this.l_MarathonSkills.Name = "l_MarathonSkills";
            this.l_MarathonSkills.Size = new System.Drawing.Size(336, 31);
            this.l_MarathonSkills.TabIndex = 0;
            this.l_MarathonSkills.Text = "MARATHON SKILLS 2016";
            // 
            // pnl_Female
            // 
            this.pnl_Female.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_Female.Controls.Add(this.l_Female);
            this.pnl_Female.Controls.Add(this.pb_Female);
            this.pnl_Female.Location = new System.Drawing.Point(206, 201);
            this.pnl_Female.Name = "pnl_Female";
            this.pnl_Female.Size = new System.Drawing.Size(140, 152);
            this.pnl_Female.TabIndex = 32;
            // 
            // l_Female
            // 
            this.l_Female.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Female.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Female.Location = new System.Drawing.Point(31, 121);
            this.l_Female.Name = "l_Female";
            this.l_Female.Size = new System.Drawing.Size(85, 22);
            this.l_Female.TabIndex = 15;
            this.l_Female.Text = "Женский";
            this.l_Female.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Female
            // 
            this.pb_Female.Image = ((System.Drawing.Image)(resources.GetObject("pb_Female.Image")));
            this.pb_Female.Location = new System.Drawing.Point(31, 12);
            this.pb_Female.Name = "pb_Female";
            this.pb_Female.Size = new System.Drawing.Size(85, 106);
            this.pb_Female.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Female.TabIndex = 14;
            this.pb_Female.TabStop = false;
            this.pb_Female.Click += new System.EventHandler(this.pb_Female_Click);
            // 
            // pnl_Male
            // 
            this.pnl_Male.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_Male.Controls.Add(this.l_Male);
            this.pnl_Male.Controls.Add(this.pb_Male);
            this.pnl_Male.Location = new System.Drawing.Point(28, 201);
            this.pnl_Male.Name = "pnl_Male";
            this.pnl_Male.Size = new System.Drawing.Size(140, 152);
            this.pnl_Male.TabIndex = 31;
            // 
            // l_Male
            // 
            this.l_Male.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Male.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Male.Location = new System.Drawing.Point(27, 121);
            this.l_Male.Name = "l_Male";
            this.l_Male.Size = new System.Drawing.Size(79, 22);
            this.l_Male.TabIndex = 15;
            this.l_Male.Text = "Мужской";
            this.l_Male.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Male
            // 
            this.pb_Male.Image = ((System.Drawing.Image)(resources.GetObject("pb_Male.Image")));
            this.pb_Male.Location = new System.Drawing.Point(27, 12);
            this.pb_Male.Name = "pb_Male";
            this.pb_Male.Size = new System.Drawing.Size(85, 106);
            this.pb_Male.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Male.TabIndex = 14;
            this.pb_Male.TabStop = false;
            this.pb_Male.Click += new System.EventHandler(this.pb_Male_Click);
            // 
            // l_Expenses
            // 
            this.l_Expenses.AutoSize = true;
            this.l_Expenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Expenses.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Expenses.Location = new System.Drawing.Point(535, 330);
            this.l_Expenses.Name = "l_Expenses";
            this.l_Expenses.Size = new System.Drawing.Size(202, 24);
            this.l_Expenses.TabIndex = 33;
            this.l_Expenses.Text = "Ежедневно тратится";
            // 
            // l_YourBMR
            // 
            this.l_YourBMR.AutoSize = true;
            this.l_YourBMR.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_YourBMR.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_YourBMR.Location = new System.Drawing.Point(616, 290);
            this.l_YourBMR.Name = "l_YourBMR";
            this.l_YourBMR.Size = new System.Drawing.Size(121, 29);
            this.l_YourBMR.TabIndex = 34;
            this.l_YourBMR.Text = "Ваш BMR";
            // 
            // l_Sit
            // 
            this.l_Sit.AutoSize = true;
            this.l_Sit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Sit.ForeColor = System.Drawing.Color.Blue;
            this.l_Sit.Location = new System.Drawing.Point(503, 373);
            this.l_Sit.Name = "l_Sit";
            this.l_Sit.Size = new System.Drawing.Size(93, 24);
            this.l_Sit.TabIndex = 35;
            this.l_Sit.Text = "Сидячий:";
            // 
            // l_AverageActivity
            // 
            this.l_AverageActivity.AutoSize = true;
            this.l_AverageActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_AverageActivity.ForeColor = System.Drawing.Color.DarkKhaki;
            this.l_AverageActivity.Location = new System.Drawing.Point(503, 445);
            this.l_AverageActivity.Name = "l_AverageActivity";
            this.l_AverageActivity.Size = new System.Drawing.Size(202, 24);
            this.l_AverageActivity.TabIndex = 37;
            this.l_AverageActivity.Text = "Средняя активность:";
            // 
            // l_StrongActivity
            // 
            this.l_StrongActivity.AutoSize = true;
            this.l_StrongActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_StrongActivity.ForeColor = System.Drawing.Color.Coral;
            this.l_StrongActivity.Location = new System.Drawing.Point(503, 484);
            this.l_StrongActivity.Name = "l_StrongActivity";
            this.l_StrongActivity.Size = new System.Drawing.Size(200, 24);
            this.l_StrongActivity.TabIndex = 38;
            this.l_StrongActivity.Text = "Сильная активность:";
            // 
            // l_MaximumActivity
            // 
            this.l_MaximumActivity.AutoSize = true;
            this.l_MaximumActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MaximumActivity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.l_MaximumActivity.Location = new System.Drawing.Point(503, 522);
            this.l_MaximumActivity.Name = "l_MaximumActivity";
            this.l_MaximumActivity.Size = new System.Drawing.Size(255, 24);
            this.l_MaximumActivity.TabIndex = 39;
            this.l_MaximumActivity.Text = "Максимальная активность:";
            // 
            // l_SitResult
            // 
            this.l_SitResult.AutoSize = true;
            this.l_SitResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_SitResult.ForeColor = System.Drawing.Color.Blue;
            this.l_SitResult.Location = new System.Drawing.Point(777, 373);
            this.l_SitResult.Name = "l_SitResult";
            this.l_SitResult.Size = new System.Drawing.Size(20, 24);
            this.l_SitResult.TabIndex = 40;
            this.l_SitResult.Text = "0";
            // 
            // l_SmallActivity
            // 
            this.l_SmallActivity.AutoSize = true;
            this.l_SmallActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_SmallActivity.ForeColor = System.Drawing.Color.Green;
            this.l_SmallActivity.Location = new System.Drawing.Point(503, 409);
            this.l_SmallActivity.Name = "l_SmallActivity";
            this.l_SmallActivity.Size = new System.Drawing.Size(222, 24);
            this.l_SmallActivity.TabIndex = 36;
            this.l_SmallActivity.Text = "Маленькая активность:";
            // 
            // l_SmallActivityResult
            // 
            this.l_SmallActivityResult.AutoSize = true;
            this.l_SmallActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_SmallActivityResult.ForeColor = System.Drawing.Color.Green;
            this.l_SmallActivityResult.Location = new System.Drawing.Point(777, 409);
            this.l_SmallActivityResult.Name = "l_SmallActivityResult";
            this.l_SmallActivityResult.Size = new System.Drawing.Size(20, 24);
            this.l_SmallActivityResult.TabIndex = 41;
            this.l_SmallActivityResult.Text = "0";
            // 
            // l_AverageActivityResult
            // 
            this.l_AverageActivityResult.AutoSize = true;
            this.l_AverageActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_AverageActivityResult.ForeColor = System.Drawing.Color.DarkKhaki;
            this.l_AverageActivityResult.Location = new System.Drawing.Point(777, 445);
            this.l_AverageActivityResult.Name = "l_AverageActivityResult";
            this.l_AverageActivityResult.Size = new System.Drawing.Size(20, 24);
            this.l_AverageActivityResult.TabIndex = 42;
            this.l_AverageActivityResult.Text = "0";
            // 
            // l_StrongActivityResult
            // 
            this.l_StrongActivityResult.AutoSize = true;
            this.l_StrongActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_StrongActivityResult.ForeColor = System.Drawing.Color.Coral;
            this.l_StrongActivityResult.Location = new System.Drawing.Point(777, 484);
            this.l_StrongActivityResult.Name = "l_StrongActivityResult";
            this.l_StrongActivityResult.Size = new System.Drawing.Size(20, 24);
            this.l_StrongActivityResult.TabIndex = 43;
            this.l_StrongActivityResult.Text = "0";
            // 
            // l_MaximumActivityResult
            // 
            this.l_MaximumActivityResult.AutoSize = true;
            this.l_MaximumActivityResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MaximumActivityResult.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.l_MaximumActivityResult.Location = new System.Drawing.Point(777, 522);
            this.l_MaximumActivityResult.Name = "l_MaximumActivityResult";
            this.l_MaximumActivityResult.Size = new System.Drawing.Size(20, 24);
            this.l_MaximumActivityResult.TabIndex = 44;
            this.l_MaximumActivityResult.Text = "0";
            // 
            // pb_Information
            // 
            this.pb_Information.Image = ((System.Drawing.Image)(resources.GetObject("pb_Information.Image")));
            this.pb_Information.Location = new System.Drawing.Point(772, 328);
            this.pb_Information.Name = "pb_Information";
            this.pb_Information.Size = new System.Drawing.Size(25, 25);
            this.pb_Information.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Information.TabIndex = 45;
            this.pb_Information.TabStop = false;
            this.pb_Information.Click += new System.EventHandler(this.pb_Information_Click);
            // 
            // pnl_InfoCheckpoint
            // 
            this.pnl_InfoCheckpoint.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_InfoCheckpoint.Controls.Add(this.label10);
            this.pnl_InfoCheckpoint.Controls.Add(this.label9);
            this.pnl_InfoCheckpoint.Controls.Add(this.label8);
            this.pnl_InfoCheckpoint.Controls.Add(this.label7);
            this.pnl_InfoCheckpoint.Controls.Add(this.label6);
            this.pnl_InfoCheckpoint.Controls.Add(this.label5);
            this.pnl_InfoCheckpoint.Controls.Add(this.label4);
            this.pnl_InfoCheckpoint.Controls.Add(this.label3);
            this.pnl_InfoCheckpoint.Controls.Add(this.label2);
            this.pnl_InfoCheckpoint.Controls.Add(this.label1);
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_CloseInfo);
            this.pnl_InfoCheckpoint.Controls.Add(this.l_ThisDescription);
            this.pnl_InfoCheckpoint.Controls.Add(this.l_LevelsActivity);
            this.pnl_InfoCheckpoint.Location = new System.Drawing.Point(190, 178);
            this.pnl_InfoCheckpoint.Name = "pnl_InfoCheckpoint";
            this.pnl_InfoCheckpoint.Size = new System.Drawing.Size(568, 303);
            this.pnl_InfoCheckpoint.TabIndex = 46;
            this.pnl_InfoCheckpoint.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label10.Location = new System.Drawing.Point(275, 242);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(264, 20);
            this.label10.TabIndex = 30;
            this.label10.Text = "тренировки чаще, чем раз в день";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label9.Location = new System.Drawing.Point(223, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(336, 20);
            this.label9.TabIndex = 29;
            this.label9.Text = "интенсивные тренировки 6-7 раз в неделю";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(224, 178);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(232, 20);
            this.label8.TabIndex = 28;
            this.label8.Text = "тренировки 3-5 раз в неделю";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(244, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(241, 20);
            this.label7.TabIndex = 27;
            this.label7.Text = "тренировки 1-3 раза в неделю";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(27, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(242, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "Максимальная активность:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(27, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(190, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "Сильная активность:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(27, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(191, 20);
            this.label4.TabIndex = 24;
            this.label4.Text = "Средняя активность:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(121, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(262, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "отсутствие физической нагрузки";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(27, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(211, 20);
            this.label2.TabIndex = 22;
            this.label2.Text = "Маленькая активность:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(27, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Сидячий:";
            // 
            // pb_CloseInfo
            // 
            this.pb_CloseInfo.Image = ((System.Drawing.Image)(resources.GetObject("pb_CloseInfo.Image")));
            this.pb_CloseInfo.Location = new System.Drawing.Point(524, 14);
            this.pb_CloseInfo.Name = "pb_CloseInfo";
            this.pb_CloseInfo.Size = new System.Drawing.Size(15, 15);
            this.pb_CloseInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_CloseInfo.TabIndex = 20;
            this.pb_CloseInfo.TabStop = false;
            this.pb_CloseInfo.Click += new System.EventHandler(this.pb_CloseInfo_Click);
            // 
            // l_ThisDescription
            // 
            this.l_ThisDescription.AutoSize = true;
            this.l_ThisDescription.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_ThisDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_ThisDescription.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_ThisDescription.Location = new System.Drawing.Point(48, 59);
            this.l_ThisDescription.Name = "l_ThisDescription";
            this.l_ThisDescription.Size = new System.Drawing.Size(308, 20);
            this.l_ThisDescription.TabIndex = 7;
            this.l_ThisDescription.Text = "Это описание всех уровней активности";
            // 
            // l_LevelsActivity
            // 
            this.l_LevelsActivity.AutoSize = true;
            this.l_LevelsActivity.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_LevelsActivity.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_LevelsActivity.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_LevelsActivity.Location = new System.Drawing.Point(183, 16);
            this.l_LevelsActivity.Name = "l_LevelsActivity";
            this.l_LevelsActivity.Size = new System.Drawing.Size(240, 29);
            this.l_LevelsActivity.TabIndex = 6;
            this.l_LevelsActivity.Text = "Уровни активности";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // BMR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.pnl_InfoCheckpoint);
            this.Controls.Add(this.pb_Information);
            this.Controls.Add(this.l_MaximumActivityResult);
            this.Controls.Add(this.l_StrongActivityResult);
            this.Controls.Add(this.l_AverageActivityResult);
            this.Controls.Add(this.l_SmallActivityResult);
            this.Controls.Add(this.l_SitResult);
            this.Controls.Add(this.l_MaximumActivity);
            this.Controls.Add(this.l_StrongActivity);
            this.Controls.Add(this.l_AverageActivity);
            this.Controls.Add(this.l_SmallActivity);
            this.Controls.Add(this.l_Sit);
            this.Controls.Add(this.l_YourBMR);
            this.Controls.Add(this.l_Expenses);
            this.Controls.Add(this.pnl_Female);
            this.Controls.Add(this.pnl_Male);
            this.Controls.Add(this.pnl_Down);
            this.Controls.Add(this.pnl_Up);
            this.Controls.Add(this.tb_Age);
            this.Controls.Add(this.l_Age);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Calculate);
            this.Controls.Add(this.l_Kg);
            this.Controls.Add(this.l_Cm);
            this.Controls.Add(this.tb_Weight);
            this.Controls.Add(this.tb_Height);
            this.Controls.Add(this.l_Weight);
            this.Controls.Add(this.l_Height);
            this.Controls.Add(this.l_BMRCalculator);
            this.Name = "BMR";
            this.Text = "BMR";
            this.Load += new System.EventHandler(this.BMR_Load);
            this.pnl_Down.ResumeLayout(false);
            this.pnl_Down.PerformLayout();
            this.pnl_Up.ResumeLayout(false);
            this.pnl_Up.PerformLayout();
            this.pnl_Female.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Female)).EndInit();
            this.pnl_Male.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Male)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Information)).EndInit();
            this.pnl_InfoCheckpoint.ResumeLayout(false);
            this.pnl_InfoCheckpoint.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_CloseInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label l_BMRCalculator;
        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_Calculate;
        private System.Windows.Forms.Label l_Kg;
        private System.Windows.Forms.Label l_Cm;
        private System.Windows.Forms.TextBox tb_Weight;
        private System.Windows.Forms.TextBox tb_Height;
        private System.Windows.Forms.Label l_Weight;
        private System.Windows.Forms.Label l_Height;
        private System.Windows.Forms.TextBox tb_Age;
        private System.Windows.Forms.Label l_Age;
        public System.Windows.Forms.Panel pnl_Down;
        public System.Windows.Forms.Label l_Count;
        public System.Windows.Forms.Panel pnl_Up;
        private System.Windows.Forms.Button btn_Back;
        public System.Windows.Forms.Label l_MarathonSkills;
        private System.Windows.Forms.Panel pnl_Female;
        private System.Windows.Forms.Label l_Female;
        private System.Windows.Forms.PictureBox pb_Female;
        private System.Windows.Forms.Panel pnl_Male;
        private System.Windows.Forms.Label l_Male;
        private System.Windows.Forms.PictureBox pb_Male;
        public System.Windows.Forms.Label l_Expenses;
        public System.Windows.Forms.Label l_YourBMR;
        public System.Windows.Forms.Label l_Sit;
        public System.Windows.Forms.Label l_AverageActivity;
        public System.Windows.Forms.Label l_StrongActivity;
        public System.Windows.Forms.Label l_MaximumActivity;
        public System.Windows.Forms.Label l_SitResult;
        public System.Windows.Forms.Label l_SmallActivity;
        public System.Windows.Forms.Label l_SmallActivityResult;
        public System.Windows.Forms.Label l_AverageActivityResult;
        public System.Windows.Forms.Label l_StrongActivityResult;
        public System.Windows.Forms.Label l_MaximumActivityResult;
        private System.Windows.Forms.PictureBox pb_Information;
        private System.Windows.Forms.Panel pnl_InfoCheckpoint;
        private System.Windows.Forms.PictureBox pb_CloseInfo;
        private System.Windows.Forms.Label l_ThisDescription;
        private System.Windows.Forms.Label l_LevelsActivity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer;
    }
}