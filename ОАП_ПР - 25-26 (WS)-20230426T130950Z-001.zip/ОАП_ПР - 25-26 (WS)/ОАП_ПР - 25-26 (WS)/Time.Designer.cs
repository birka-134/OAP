﻿
namespace ОАП_ПР___25_26__WS_
{
    partial class Time
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Time));
            this.l_HowLong = new System.Windows.Forms.Label();
            this.l_ItemName = new System.Windows.Forms.Label();
            this.l_Inf = new System.Windows.Forms.Label();
            this.pnl_Down = new System.Windows.Forms.Panel();
            this.l_Count = new System.Windows.Forms.Label();
            this.pnl_Up = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.l_MarathonSkills = new System.Windows.Forms.Label();
            this.tc_SpeedDistance = new System.Windows.Forms.TabControl();
            this.tp_Speed = new System.Windows.Forms.TabPage();
            this.l_Horse = new System.Windows.Forms.Label();
            this.l_Slug = new System.Windows.Forms.Label();
            this.pb_Horse = new System.Windows.Forms.PictureBox();
            this.pb_Slug = new System.Windows.Forms.PictureBox();
            this.l_Jaguar = new System.Windows.Forms.Label();
            this.pb_F1Car = new System.Windows.Forms.PictureBox();
            this.l_Capybara = new System.Windows.Forms.Label();
            this.pb_Jaguar = new System.Windows.Forms.PictureBox();
            this.l_Sloth = new System.Windows.Forms.Label();
            this.pb_Capybara = new System.Windows.Forms.PictureBox();
            this.l_Worm = new System.Windows.Forms.Label();
            this.pb_Sloth = new System.Windows.Forms.PictureBox();
            this.l_F1Car = new System.Windows.Forms.Label();
            this.pb_Worm = new System.Windows.Forms.PictureBox();
            this.tp_Distance = new System.Windows.Forms.TabPage();
            this.l_Bus = new System.Windows.Forms.Label();
            this.l_Ronaldinho = new System.Windows.Forms.Label();
            this.l_FootballField = new System.Windows.Forms.Label();
            this.l_Havaianas = new System.Windows.Forms.Label();
            this.l_AirbusA380 = new System.Windows.Forms.Label();
            this.pb_Havaianas = new System.Windows.Forms.PictureBox();
            this.pb_FootballField = new System.Windows.Forms.PictureBox();
            this.pb_Ronaldinho = new System.Windows.Forms.PictureBox();
            this.pb_Bus = new System.Windows.Forms.PictureBox();
            this.pb_AirbusA380 = new System.Windows.Forms.PictureBox();
            this.pb_ItemPhoto = new System.Windows.Forms.PictureBox();
            this.pnl_Item = new System.Windows.Forms.Panel();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pnl_Down.SuspendLayout();
            this.pnl_Up.SuspendLayout();
            this.tc_SpeedDistance.SuspendLayout();
            this.tp_Speed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Horse)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Slug)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_F1Car)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Jaguar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Capybara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Sloth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Worm)).BeginInit();
            this.tp_Distance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Havaianas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_FootballField)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Ronaldinho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Bus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_AirbusA380)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ItemPhoto)).BeginInit();
            this.pnl_Item.SuspendLayout();
            this.SuspendLayout();
            // 
            // l_HowLong
            // 
            this.l_HowLong.AutoSize = true;
            this.l_HowLong.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_HowLong.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_HowLong.Location = new System.Drawing.Point(257, 77);
            this.l_HowLong.Name = "l_HowLong";
            this.l_HowLong.Size = new System.Drawing.Size(348, 29);
            this.l_HowLong.TabIndex = 5;
            this.l_HowLong.Text = "Насколько долгий марафон?";
            // 
            // l_ItemName
            // 
            this.l_ItemName.AutoSize = true;
            this.l_ItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_ItemName.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_ItemName.Location = new System.Drawing.Point(77, 32);
            this.l_ItemName.Name = "l_ItemName";
            this.l_ItemName.Size = new System.Drawing.Size(293, 29);
            this.l_ItemName.TabIndex = 8;
            this.l_ItemName.Text = "Имя выбранного пункта";
            // 
            // l_Inf
            // 
            this.l_Inf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Inf.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Inf.Location = new System.Drawing.Point(47, 396);
            this.l_Inf.Name = "l_Inf";
            this.l_Inf.Size = new System.Drawing.Size(351, 93);
            this.l_Inf.TabIndex = 9;
            this.l_Inf.Text = "Информация";
            // 
            // pnl_Down
            // 
            this.pnl_Down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Down.Controls.Add(this.l_Count);
            this.pnl_Down.Location = new System.Drawing.Point(-1, 624);
            this.pnl_Down.Name = "pnl_Down";
            this.pnl_Down.Size = new System.Drawing.Size(886, 39);
            this.pnl_Down.TabIndex = 11;
            // 
            // l_Count
            // 
            this.l_Count.AutoSize = true;
            this.l_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Count.ForeColor = System.Drawing.SystemColors.Window;
            this.l_Count.Location = new System.Drawing.Point(306, 12);
            this.l_Count.Name = "l_Count";
            this.l_Count.Size = new System.Drawing.Size(340, 16);
            this.l_Count.TabIndex = 1;
            this.l_Count.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // pnl_Up
            // 
            this.pnl_Up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Up.Controls.Add(this.btn_Back);
            this.pnl_Up.Controls.Add(this.l_MarathonSkills);
            this.pnl_Up.Location = new System.Drawing.Point(-1, -3);
            this.pnl_Up.Name = "pnl_Up";
            this.pnl_Up.Size = new System.Drawing.Size(886, 60);
            this.pnl_Up.TabIndex = 10;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Back.FlatAppearance.BorderSize = 0;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Back.Location = new System.Drawing.Point(30, 22);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Назад";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // l_MarathonSkills
            // 
            this.l_MarathonSkills.AutoSize = true;
            this.l_MarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MarathonSkills.ForeColor = System.Drawing.SystemColors.Window;
            this.l_MarathonSkills.Location = new System.Drawing.Point(135, 14);
            this.l_MarathonSkills.Name = "l_MarathonSkills";
            this.l_MarathonSkills.Size = new System.Drawing.Size(336, 31);
            this.l_MarathonSkills.TabIndex = 0;
            this.l_MarathonSkills.Text = "MARATHON SKILLS 2016";
            // 
            // tc_SpeedDistance
            // 
            this.tc_SpeedDistance.Controls.Add(this.tp_Speed);
            this.tc_SpeedDistance.Controls.Add(this.tp_Distance);
            this.tc_SpeedDistance.Location = new System.Drawing.Point(524, 109);
            this.tc_SpeedDistance.Name = "tc_SpeedDistance";
            this.tc_SpeedDistance.SelectedIndex = 0;
            this.tc_SpeedDistance.Size = new System.Drawing.Size(348, 509);
            this.tc_SpeedDistance.TabIndex = 12;
            // 
            // tp_Speed
            // 
            this.tp_Speed.Controls.Add(this.l_Horse);
            this.tp_Speed.Controls.Add(this.l_Slug);
            this.tp_Speed.Controls.Add(this.pb_Horse);
            this.tp_Speed.Controls.Add(this.pb_Slug);
            this.tp_Speed.Controls.Add(this.l_Jaguar);
            this.tp_Speed.Controls.Add(this.pb_F1Car);
            this.tp_Speed.Controls.Add(this.l_Capybara);
            this.tp_Speed.Controls.Add(this.pb_Jaguar);
            this.tp_Speed.Controls.Add(this.l_Sloth);
            this.tp_Speed.Controls.Add(this.pb_Capybara);
            this.tp_Speed.Controls.Add(this.l_Worm);
            this.tp_Speed.Controls.Add(this.pb_Sloth);
            this.tp_Speed.Controls.Add(this.l_F1Car);
            this.tp_Speed.Controls.Add(this.pb_Worm);
            this.tp_Speed.Location = new System.Drawing.Point(4, 22);
            this.tp_Speed.Name = "tp_Speed";
            this.tp_Speed.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Speed.Size = new System.Drawing.Size(340, 483);
            this.tp_Speed.TabIndex = 0;
            this.tp_Speed.Text = "Скорость";
            this.tp_Speed.UseVisualStyleBackColor = true;
            // 
            // l_Horse
            // 
            this.l_Horse.AutoSize = true;
            this.l_Horse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Horse.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Horse.Location = new System.Drawing.Point(127, 428);
            this.l_Horse.Name = "l_Horse";
            this.l_Horse.Size = new System.Drawing.Size(52, 20);
            this.l_Horse.TabIndex = 35;
            this.l_Horse.Text = "Horse";
            // 
            // l_Slug
            // 
            this.l_Slug.AutoSize = true;
            this.l_Slug.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Slug.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Slug.Location = new System.Drawing.Point(127, 360);
            this.l_Slug.Name = "l_Slug";
            this.l_Slug.Size = new System.Drawing.Size(41, 20);
            this.l_Slug.TabIndex = 34;
            this.l_Slug.Text = "Slug";
            // 
            // pb_Horse
            // 
            this.pb_Horse.Image = ((System.Drawing.Image)(resources.GetObject("pb_Horse.Image")));
            this.pb_Horse.Location = new System.Drawing.Point(22, 409);
            this.pb_Horse.Name = "pb_Horse";
            this.pb_Horse.Size = new System.Drawing.Size(85, 60);
            this.pb_Horse.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Horse.TabIndex = 33;
            this.pb_Horse.TabStop = false;
            this.pb_Horse.Click += new System.EventHandler(this.pb_Horse_Click);
            // 
            // pb_Slug
            // 
            this.pb_Slug.Image = ((System.Drawing.Image)(resources.GetObject("pb_Slug.Image")));
            this.pb_Slug.Location = new System.Drawing.Point(22, 343);
            this.pb_Slug.Name = "pb_Slug";
            this.pb_Slug.Size = new System.Drawing.Size(85, 60);
            this.pb_Slug.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Slug.TabIndex = 32;
            this.pb_Slug.TabStop = false;
            this.pb_Slug.Click += new System.EventHandler(this.pb_Slug_Click);
            // 
            // l_Jaguar
            // 
            this.l_Jaguar.AutoSize = true;
            this.l_Jaguar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Jaguar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Jaguar.Location = new System.Drawing.Point(127, 295);
            this.l_Jaguar.Name = "l_Jaguar";
            this.l_Jaguar.Size = new System.Drawing.Size(58, 20);
            this.l_Jaguar.TabIndex = 31;
            this.l_Jaguar.Text = "Jaguar";
            // 
            // pb_F1Car
            // 
            this.pb_F1Car.Image = ((System.Drawing.Image)(resources.GetObject("pb_F1Car.Image")));
            this.pb_F1Car.Location = new System.Drawing.Point(22, 13);
            this.pb_F1Car.Name = "pb_F1Car";
            this.pb_F1Car.Size = new System.Drawing.Size(85, 60);
            this.pb_F1Car.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_F1Car.TabIndex = 23;
            this.pb_F1Car.TabStop = false;
            this.pb_F1Car.Click += new System.EventHandler(this.pb_F1Car_Click);
            // 
            // l_Capybara
            // 
            this.l_Capybara.AutoSize = true;
            this.l_Capybara.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Capybara.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Capybara.Location = new System.Drawing.Point(127, 232);
            this.l_Capybara.Name = "l_Capybara";
            this.l_Capybara.Size = new System.Drawing.Size(77, 20);
            this.l_Capybara.TabIndex = 30;
            this.l_Capybara.Text = "Capybara";
            // 
            // pb_Jaguar
            // 
            this.pb_Jaguar.Image = ((System.Drawing.Image)(resources.GetObject("pb_Jaguar.Image")));
            this.pb_Jaguar.Location = new System.Drawing.Point(22, 277);
            this.pb_Jaguar.Name = "pb_Jaguar";
            this.pb_Jaguar.Size = new System.Drawing.Size(85, 60);
            this.pb_Jaguar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Jaguar.TabIndex = 24;
            this.pb_Jaguar.TabStop = false;
            this.pb_Jaguar.Click += new System.EventHandler(this.pb_Jaguar_Click);
            // 
            // l_Sloth
            // 
            this.l_Sloth.AutoSize = true;
            this.l_Sloth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Sloth.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Sloth.Location = new System.Drawing.Point(127, 168);
            this.l_Sloth.Name = "l_Sloth";
            this.l_Sloth.Size = new System.Drawing.Size(46, 20);
            this.l_Sloth.TabIndex = 29;
            this.l_Sloth.Text = "Sloth";
            // 
            // pb_Capybara
            // 
            this.pb_Capybara.Image = ((System.Drawing.Image)(resources.GetObject("pb_Capybara.Image")));
            this.pb_Capybara.Location = new System.Drawing.Point(22, 211);
            this.pb_Capybara.Name = "pb_Capybara";
            this.pb_Capybara.Size = new System.Drawing.Size(85, 60);
            this.pb_Capybara.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Capybara.TabIndex = 25;
            this.pb_Capybara.TabStop = false;
            this.pb_Capybara.Click += new System.EventHandler(this.pb_Capybara_Click);
            // 
            // l_Worm
            // 
            this.l_Worm.AutoSize = true;
            this.l_Worm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Worm.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Worm.Location = new System.Drawing.Point(127, 101);
            this.l_Worm.Name = "l_Worm";
            this.l_Worm.Size = new System.Drawing.Size(51, 20);
            this.l_Worm.TabIndex = 28;
            this.l_Worm.Text = "Worm";
            // 
            // pb_Sloth
            // 
            this.pb_Sloth.Image = ((System.Drawing.Image)(resources.GetObject("pb_Sloth.Image")));
            this.pb_Sloth.InitialImage = null;
            this.pb_Sloth.Location = new System.Drawing.Point(22, 145);
            this.pb_Sloth.Name = "pb_Sloth";
            this.pb_Sloth.Size = new System.Drawing.Size(85, 60);
            this.pb_Sloth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Sloth.TabIndex = 26;
            this.pb_Sloth.TabStop = false;
            this.pb_Sloth.Click += new System.EventHandler(this.pb_Sloth_Click);
            // 
            // l_F1Car
            // 
            this.l_F1Car.AutoSize = true;
            this.l_F1Car.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_F1Car.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_F1Car.Location = new System.Drawing.Point(127, 38);
            this.l_F1Car.Name = "l_F1Car";
            this.l_F1Car.Size = new System.Drawing.Size(57, 20);
            this.l_F1Car.TabIndex = 22;
            this.l_F1Car.Text = "F1 Car";
            // 
            // pb_Worm
            // 
            this.pb_Worm.Image = ((System.Drawing.Image)(resources.GetObject("pb_Worm.Image")));
            this.pb_Worm.Location = new System.Drawing.Point(22, 79);
            this.pb_Worm.Name = "pb_Worm";
            this.pb_Worm.Size = new System.Drawing.Size(85, 60);
            this.pb_Worm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Worm.TabIndex = 27;
            this.pb_Worm.TabStop = false;
            this.pb_Worm.Click += new System.EventHandler(this.pb_Worm_Click);
            // 
            // tp_Distance
            // 
            this.tp_Distance.Controls.Add(this.l_Bus);
            this.tp_Distance.Controls.Add(this.l_Ronaldinho);
            this.tp_Distance.Controls.Add(this.l_FootballField);
            this.tp_Distance.Controls.Add(this.l_Havaianas);
            this.tp_Distance.Controls.Add(this.l_AirbusA380);
            this.tp_Distance.Controls.Add(this.pb_Havaianas);
            this.tp_Distance.Controls.Add(this.pb_FootballField);
            this.tp_Distance.Controls.Add(this.pb_Ronaldinho);
            this.tp_Distance.Controls.Add(this.pb_Bus);
            this.tp_Distance.Controls.Add(this.pb_AirbusA380);
            this.tp_Distance.Location = new System.Drawing.Point(4, 22);
            this.tp_Distance.Name = "tp_Distance";
            this.tp_Distance.Padding = new System.Windows.Forms.Padding(3);
            this.tp_Distance.Size = new System.Drawing.Size(340, 483);
            this.tp_Distance.TabIndex = 1;
            this.tp_Distance.Text = "Дистанция";
            this.tp_Distance.UseVisualStyleBackColor = true;
            // 
            // l_Bus
            // 
            this.l_Bus.AutoSize = true;
            this.l_Bus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Bus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Bus.Location = new System.Drawing.Point(133, 407);
            this.l_Bus.Name = "l_Bus";
            this.l_Bus.Size = new System.Drawing.Size(37, 20);
            this.l_Bus.TabIndex = 21;
            this.l_Bus.Text = "Bus";
            // 
            // l_Ronaldinho
            // 
            this.l_Ronaldinho.AutoSize = true;
            this.l_Ronaldinho.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Ronaldinho.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Ronaldinho.Location = new System.Drawing.Point(133, 309);
            this.l_Ronaldinho.Name = "l_Ronaldinho";
            this.l_Ronaldinho.Size = new System.Drawing.Size(90, 20);
            this.l_Ronaldinho.TabIndex = 20;
            this.l_Ronaldinho.Text = "Ronaldinho";
            // 
            // l_FootballField
            // 
            this.l_FootballField.AutoSize = true;
            this.l_FootballField.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_FootballField.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_FootballField.Location = new System.Drawing.Point(133, 226);
            this.l_FootballField.Name = "l_FootballField";
            this.l_FootballField.Size = new System.Drawing.Size(104, 20);
            this.l_FootballField.TabIndex = 19;
            this.l_FootballField.Text = "Football Field";
            // 
            // l_Havaianas
            // 
            this.l_Havaianas.AutoSize = true;
            this.l_Havaianas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Havaianas.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Havaianas.Location = new System.Drawing.Point(133, 130);
            this.l_Havaianas.Name = "l_Havaianas";
            this.l_Havaianas.Size = new System.Drawing.Size(133, 20);
            this.l_Havaianas.TabIndex = 18;
            this.l_Havaianas.Text = "Pair of Havaianas";
            // 
            // l_AirbusA380
            // 
            this.l_AirbusA380.AutoSize = true;
            this.l_AirbusA380.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_AirbusA380.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_AirbusA380.Location = new System.Drawing.Point(133, 43);
            this.l_AirbusA380.Name = "l_AirbusA380";
            this.l_AirbusA380.Size = new System.Drawing.Size(96, 20);
            this.l_AirbusA380.TabIndex = 13;
            this.l_AirbusA380.Text = "Airbus A380";
            // 
            // pb_Havaianas
            // 
            this.pb_Havaianas.Image = ((System.Drawing.Image)(resources.GetObject("pb_Havaianas.Image")));
            this.pb_Havaianas.Location = new System.Drawing.Point(22, 103);
            this.pb_Havaianas.Name = "pb_Havaianas";
            this.pb_Havaianas.Size = new System.Drawing.Size(85, 85);
            this.pb_Havaianas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Havaianas.TabIndex = 17;
            this.pb_Havaianas.TabStop = false;
            this.pb_Havaianas.Click += new System.EventHandler(this.pb_Havaianas_Click);
            // 
            // pb_FootballField
            // 
            this.pb_FootballField.Image = ((System.Drawing.Image)(resources.GetObject("pb_FootballField.Image")));
            this.pb_FootballField.Location = new System.Drawing.Point(22, 194);
            this.pb_FootballField.Name = "pb_FootballField";
            this.pb_FootballField.Size = new System.Drawing.Size(85, 85);
            this.pb_FootballField.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_FootballField.TabIndex = 16;
            this.pb_FootballField.TabStop = false;
            this.pb_FootballField.Click += new System.EventHandler(this.pb_FootballField_Click);
            // 
            // pb_Ronaldinho
            // 
            this.pb_Ronaldinho.Image = ((System.Drawing.Image)(resources.GetObject("pb_Ronaldinho.Image")));
            this.pb_Ronaldinho.Location = new System.Drawing.Point(22, 285);
            this.pb_Ronaldinho.Name = "pb_Ronaldinho";
            this.pb_Ronaldinho.Size = new System.Drawing.Size(85, 85);
            this.pb_Ronaldinho.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Ronaldinho.TabIndex = 15;
            this.pb_Ronaldinho.TabStop = false;
            this.pb_Ronaldinho.Click += new System.EventHandler(this.pb_Ronaldinho_Click);
            // 
            // pb_Bus
            // 
            this.pb_Bus.Image = ((System.Drawing.Image)(resources.GetObject("pb_Bus.Image")));
            this.pb_Bus.Location = new System.Drawing.Point(22, 376);
            this.pb_Bus.Name = "pb_Bus";
            this.pb_Bus.Size = new System.Drawing.Size(85, 85);
            this.pb_Bus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Bus.TabIndex = 14;
            this.pb_Bus.TabStop = false;
            this.pb_Bus.Click += new System.EventHandler(this.pb_Bus_Click);
            // 
            // pb_AirbusA380
            // 
            this.pb_AirbusA380.Image = ((System.Drawing.Image)(resources.GetObject("pb_AirbusA380.Image")));
            this.pb_AirbusA380.Location = new System.Drawing.Point(22, 12);
            this.pb_AirbusA380.Name = "pb_AirbusA380";
            this.pb_AirbusA380.Size = new System.Drawing.Size(85, 85);
            this.pb_AirbusA380.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_AirbusA380.TabIndex = 13;
            this.pb_AirbusA380.TabStop = false;
            this.pb_AirbusA380.Click += new System.EventHandler(this.pb_AirbusA380_Click);
            // 
            // pb_ItemPhoto
            // 
            this.pb_ItemPhoto.Location = new System.Drawing.Point(51, 76);
            this.pb_ItemPhoto.Name = "pb_ItemPhoto";
            this.pb_ItemPhoto.Size = new System.Drawing.Size(347, 300);
            this.pb_ItemPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_ItemPhoto.TabIndex = 22;
            this.pb_ItemPhoto.TabStop = false;
            // 
            // pnl_Item
            // 
            this.pnl_Item.Controls.Add(this.pb_ItemPhoto);
            this.pnl_Item.Controls.Add(this.l_Inf);
            this.pnl_Item.Controls.Add(this.l_ItemName);
            this.pnl_Item.Location = new System.Drawing.Point(46, 111);
            this.pnl_Item.Name = "pnl_Item";
            this.pnl_Item.Size = new System.Drawing.Size(445, 506);
            this.pnl_Item.TabIndex = 23;
            this.pnl_Item.Visible = false;
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Time
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.pnl_Item);
            this.Controls.Add(this.tc_SpeedDistance);
            this.Controls.Add(this.pnl_Down);
            this.Controls.Add(this.pnl_Up);
            this.Controls.Add(this.l_HowLong);
            this.Name = "Time";
            this.Text = "Length";
            this.Load += new System.EventHandler(this.Time_Load);
            this.pnl_Down.ResumeLayout(false);
            this.pnl_Down.PerformLayout();
            this.pnl_Up.ResumeLayout(false);
            this.pnl_Up.PerformLayout();
            this.tc_SpeedDistance.ResumeLayout(false);
            this.tp_Speed.ResumeLayout(false);
            this.tp_Speed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Horse)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Slug)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_F1Car)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Jaguar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Capybara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Sloth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Worm)).EndInit();
            this.tp_Distance.ResumeLayout(false);
            this.tp_Distance.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Havaianas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_FootballField)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Ronaldinho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Bus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_AirbusA380)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ItemPhoto)).EndInit();
            this.pnl_Item.ResumeLayout(false);
            this.pnl_Item.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label l_HowLong;
        public System.Windows.Forms.Label l_ItemName;
        public System.Windows.Forms.Label l_Inf;
        public System.Windows.Forms.Panel pnl_Down;
        public System.Windows.Forms.Label l_Count;
        public System.Windows.Forms.Panel pnl_Up;
        private System.Windows.Forms.Button btn_Back;
        public System.Windows.Forms.Label l_MarathonSkills;
        private System.Windows.Forms.TabControl tc_SpeedDistance;
        private System.Windows.Forms.TabPage tp_Speed;
        private System.Windows.Forms.TabPage tp_Distance;
        private System.Windows.Forms.PictureBox pb_Havaianas;
        private System.Windows.Forms.PictureBox pb_FootballField;
        private System.Windows.Forms.PictureBox pb_Ronaldinho;
        private System.Windows.Forms.PictureBox pb_Bus;
        private System.Windows.Forms.PictureBox pb_AirbusA380;
        public System.Windows.Forms.Label l_Bus;
        public System.Windows.Forms.Label l_Ronaldinho;
        public System.Windows.Forms.Label l_FootballField;
        public System.Windows.Forms.Label l_Havaianas;
        public System.Windows.Forms.Label l_AirbusA380;
        public System.Windows.Forms.Label l_Jaguar;
        private System.Windows.Forms.PictureBox pb_F1Car;
        public System.Windows.Forms.Label l_Capybara;
        private System.Windows.Forms.PictureBox pb_Jaguar;
        public System.Windows.Forms.Label l_Sloth;
        private System.Windows.Forms.PictureBox pb_Capybara;
        public System.Windows.Forms.Label l_Worm;
        private System.Windows.Forms.PictureBox pb_Sloth;
        public System.Windows.Forms.Label l_F1Car;
        private System.Windows.Forms.PictureBox pb_Worm;
        private System.Windows.Forms.PictureBox pb_Slug;
        public System.Windows.Forms.Label l_Horse;
        public System.Windows.Forms.Label l_Slug;
        private System.Windows.Forms.PictureBox pb_Horse;
        private System.Windows.Forms.PictureBox pb_ItemPhoto;
        private System.Windows.Forms.Panel pnl_Item;
        private System.Windows.Forms.Timer timer;
    }
}