﻿
namespace ОАП_ПР___25_26__WS_
{
    partial class BMI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BMI));
            this.l_BMICalculator = new System.Windows.Forms.Label();
            this.l_Height = new System.Windows.Forms.Label();
            this.l_Weight = new System.Windows.Forms.Label();
            this.tb_Height = new System.Windows.Forms.TextBox();
            this.tb_Weight = new System.Windows.Forms.TextBox();
            this.l_Kg = new System.Windows.Forms.Label();
            this.l_Cm = new System.Windows.Forms.Label();
            this.btn_Calculate = new System.Windows.Forms.Button();
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.pnl_Down = new System.Windows.Forms.Panel();
            this.l_Count = new System.Windows.Forms.Label();
            this.pnl_Up = new System.Windows.Forms.Panel();
            this.l_MarathonSkills = new System.Windows.Forms.Label();
            this.pnl_Male = new System.Windows.Forms.Panel();
            this.l_Male = new System.Windows.Forms.Label();
            this.pb_Male = new System.Windows.Forms.PictureBox();
            this.pnl_Female = new System.Windows.Forms.Panel();
            this.l_Female = new System.Windows.Forms.Label();
            this.pb_Female = new System.Windows.Forms.PictureBox();
            this.pnl_Result = new System.Windows.Forms.Panel();
            this.pb_Result4 = new System.Windows.Forms.PictureBox();
            this.pb_Result3 = new System.Windows.Forms.PictureBox();
            this.pb_Result2 = new System.Windows.Forms.PictureBox();
            this.l_Result = new System.Windows.Forms.Label();
            this.pb_Result1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.trb_BMI = new System.Windows.Forms.TrackBar();
            this.l_BMI = new System.Windows.Forms.Label();
            this.l_Underweight = new System.Windows.Forms.Label();
            this.l_Healthy = new System.Windows.Forms.Label();
            this.l_Over = new System.Windows.Forms.Label();
            this.l_Obese = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.btn_Back = new System.Windows.Forms.Button();
            this.pnl_Down.SuspendLayout();
            this.pnl_Up.SuspendLayout();
            this.pnl_Male.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Male)).BeginInit();
            this.pnl_Female.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Female)).BeginInit();
            this.pnl_Result.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trb_BMI)).BeginInit();
            this.SuspendLayout();
            // 
            // l_BMICalculator
            // 
            this.l_BMICalculator.AutoSize = true;
            this.l_BMICalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_BMICalculator.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_BMICalculator.Location = new System.Drawing.Point(280, 82);
            this.l_BMICalculator.Name = "l_BMICalculator";
            this.l_BMICalculator.Size = new System.Drawing.Size(206, 29);
            this.l_BMICalculator.TabIndex = 10;
            this.l_BMICalculator.Text = "BMI калькулятор";
            // 
            // l_Height
            // 
            this.l_Height.AutoSize = true;
            this.l_Height.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Height.Location = new System.Drawing.Point(102, 415);
            this.l_Height.Name = "l_Height";
            this.l_Height.Size = new System.Drawing.Size(42, 16);
            this.l_Height.TabIndex = 11;
            this.l_Height.Text = "Рост:";
            // 
            // l_Weight
            // 
            this.l_Weight.AutoSize = true;
            this.l_Weight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Weight.Location = new System.Drawing.Point(109, 451);
            this.l_Weight.Name = "l_Weight";
            this.l_Weight.Size = new System.Drawing.Size(35, 16);
            this.l_Weight.TabIndex = 12;
            this.l_Weight.Text = "Вес:";
            // 
            // tb_Height
            // 
            this.tb_Height.Location = new System.Drawing.Point(150, 411);
            this.tb_Height.Name = "tb_Height";
            this.tb_Height.Size = new System.Drawing.Size(68, 20);
            this.tb_Height.TabIndex = 13;
            // 
            // tb_Weight
            // 
            this.tb_Weight.Location = new System.Drawing.Point(150, 447);
            this.tb_Weight.Name = "tb_Weight";
            this.tb_Weight.Size = new System.Drawing.Size(68, 20);
            this.tb_Weight.TabIndex = 14;
            // 
            // l_Kg
            // 
            this.l_Kg.AutoSize = true;
            this.l_Kg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Kg.Location = new System.Drawing.Point(224, 451);
            this.l_Kg.Name = "l_Kg";
            this.l_Kg.Size = new System.Drawing.Size(21, 16);
            this.l_Kg.TabIndex = 16;
            this.l_Kg.Text = "кг";
            // 
            // l_Cm
            // 
            this.l_Cm.AutoSize = true;
            this.l_Cm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Cm.Location = new System.Drawing.Point(224, 415);
            this.l_Cm.Name = "l_Cm";
            this.l_Cm.Size = new System.Drawing.Size(24, 16);
            this.l_Cm.TabIndex = 15;
            this.l_Cm.Text = "см";
            // 
            // btn_Calculate
            // 
            this.btn_Calculate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Calculate.FlatAppearance.BorderSize = 0;
            this.btn_Calculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Calculate.Location = new System.Drawing.Point(80, 500);
            this.btn_Calculate.Name = "btn_Calculate";
            this.btn_Calculate.Size = new System.Drawing.Size(98, 23);
            this.btn_Calculate.TabIndex = 17;
            this.btn_Calculate.Text = "Рассчитать";
            this.btn_Calculate.UseVisualStyleBackColor = false;
            this.btn_Calculate.Click += new System.EventHandler(this.btn_Calculate_Click);
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Cancel.FlatAppearance.BorderSize = 0;
            this.btn_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Cancel.Location = new System.Drawing.Point(206, 500);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 18;
            this.btn_Cancel.Text = "Отмена";
            this.btn_Cancel.UseVisualStyleBackColor = false;
            this.btn_Cancel.Click += new System.EventHandler(this.btn_Cancel_Click);
            // 
            // pnl_Down
            // 
            this.pnl_Down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Down.Controls.Add(this.l_Count);
            this.pnl_Down.Location = new System.Drawing.Point(-1, 624);
            this.pnl_Down.Name = "pnl_Down";
            this.pnl_Down.Size = new System.Drawing.Size(886, 39);
            this.pnl_Down.TabIndex = 20;
            // 
            // l_Count
            // 
            this.l_Count.AutoSize = true;
            this.l_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Count.ForeColor = System.Drawing.SystemColors.Window;
            this.l_Count.Location = new System.Drawing.Point(306, 12);
            this.l_Count.Name = "l_Count";
            this.l_Count.Size = new System.Drawing.Size(340, 16);
            this.l_Count.TabIndex = 1;
            this.l_Count.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // pnl_Up
            // 
            this.pnl_Up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Up.Controls.Add(this.btn_Back);
            this.pnl_Up.Controls.Add(this.l_MarathonSkills);
            this.pnl_Up.Location = new System.Drawing.Point(-1, -3);
            this.pnl_Up.Name = "pnl_Up";
            this.pnl_Up.Size = new System.Drawing.Size(886, 60);
            this.pnl_Up.TabIndex = 19;
            // 
            // l_MarathonSkills
            // 
            this.l_MarathonSkills.AutoSize = true;
            this.l_MarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MarathonSkills.ForeColor = System.Drawing.SystemColors.Window;
            this.l_MarathonSkills.Location = new System.Drawing.Point(135, 14);
            this.l_MarathonSkills.Name = "l_MarathonSkills";
            this.l_MarathonSkills.Size = new System.Drawing.Size(336, 31);
            this.l_MarathonSkills.TabIndex = 0;
            this.l_MarathonSkills.Text = "MARATHON SKILLS 2016";
            // 
            // pnl_Male
            // 
            this.pnl_Male.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_Male.Controls.Add(this.l_Male);
            this.pnl_Male.Controls.Add(this.pb_Male);
            this.pnl_Male.Location = new System.Drawing.Point(38, 221);
            this.pnl_Male.Name = "pnl_Male";
            this.pnl_Male.Size = new System.Drawing.Size(140, 152);
            this.pnl_Male.TabIndex = 21;
            // 
            // l_Male
            // 
            this.l_Male.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Male.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Male.Location = new System.Drawing.Point(27, 121);
            this.l_Male.Name = "l_Male";
            this.l_Male.Size = new System.Drawing.Size(79, 22);
            this.l_Male.TabIndex = 15;
            this.l_Male.Text = "Мужской";
            this.l_Male.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Male
            // 
            this.pb_Male.Image = ((System.Drawing.Image)(resources.GetObject("pb_Male.Image")));
            this.pb_Male.Location = new System.Drawing.Point(27, 12);
            this.pb_Male.Name = "pb_Male";
            this.pb_Male.Size = new System.Drawing.Size(85, 106);
            this.pb_Male.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Male.TabIndex = 14;
            this.pb_Male.TabStop = false;
            this.pb_Male.Click += new System.EventHandler(this.pb_Male_Click);
            // 
            // pnl_Female
            // 
            this.pnl_Female.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_Female.Controls.Add(this.l_Female);
            this.pnl_Female.Controls.Add(this.pb_Female);
            this.pnl_Female.Location = new System.Drawing.Point(216, 221);
            this.pnl_Female.Name = "pnl_Female";
            this.pnl_Female.Size = new System.Drawing.Size(140, 152);
            this.pnl_Female.TabIndex = 22;
            // 
            // l_Female
            // 
            this.l_Female.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Female.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Female.Location = new System.Drawing.Point(31, 121);
            this.l_Female.Name = "l_Female";
            this.l_Female.Size = new System.Drawing.Size(85, 22);
            this.l_Female.TabIndex = 15;
            this.l_Female.Text = "Женский";
            this.l_Female.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Female
            // 
            this.pb_Female.Image = ((System.Drawing.Image)(resources.GetObject("pb_Female.Image")));
            this.pb_Female.Location = new System.Drawing.Point(31, 12);
            this.pb_Female.Name = "pb_Female";
            this.pb_Female.Size = new System.Drawing.Size(85, 106);
            this.pb_Female.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Female.TabIndex = 14;
            this.pb_Female.TabStop = false;
            this.pb_Female.Click += new System.EventHandler(this.pb_Female_Click);
            // 
            // pnl_Result
            // 
            this.pnl_Result.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_Result.Controls.Add(this.pb_Result4);
            this.pnl_Result.Controls.Add(this.pb_Result3);
            this.pnl_Result.Controls.Add(this.pb_Result2);
            this.pnl_Result.Controls.Add(this.l_Result);
            this.pnl_Result.Controls.Add(this.pb_Result1);
            this.pnl_Result.Location = new System.Drawing.Point(590, 173);
            this.pnl_Result.Name = "pnl_Result";
            this.pnl_Result.Size = new System.Drawing.Size(187, 234);
            this.pnl_Result.TabIndex = 22;
            // 
            // pb_Result4
            // 
            this.pb_Result4.Image = ((System.Drawing.Image)(resources.GetObject("pb_Result4.Image")));
            this.pb_Result4.Location = new System.Drawing.Point(34, 23);
            this.pb_Result4.Name = "pb_Result4";
            this.pb_Result4.Size = new System.Drawing.Size(125, 176);
            this.pb_Result4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Result4.TabIndex = 18;
            this.pb_Result4.TabStop = false;
            this.pb_Result4.Visible = false;
            // 
            // pb_Result3
            // 
            this.pb_Result3.Image = ((System.Drawing.Image)(resources.GetObject("pb_Result3.Image")));
            this.pb_Result3.Location = new System.Drawing.Point(34, 23);
            this.pb_Result3.Name = "pb_Result3";
            this.pb_Result3.Size = new System.Drawing.Size(125, 176);
            this.pb_Result3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Result3.TabIndex = 17;
            this.pb_Result3.TabStop = false;
            // 
            // pb_Result2
            // 
            this.pb_Result2.Image = ((System.Drawing.Image)(resources.GetObject("pb_Result2.Image")));
            this.pb_Result2.Location = new System.Drawing.Point(34, 23);
            this.pb_Result2.Name = "pb_Result2";
            this.pb_Result2.Size = new System.Drawing.Size(125, 176);
            this.pb_Result2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Result2.TabIndex = 16;
            this.pb_Result2.TabStop = false;
            // 
            // l_Result
            // 
            this.l_Result.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Result.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Result.Location = new System.Drawing.Point(1, 208);
            this.l_Result.Name = "l_Result";
            this.l_Result.Size = new System.Drawing.Size(184, 20);
            this.l_Result.TabIndex = 15;
            this.l_Result.Text = "Ожирение";
            this.l_Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pb_Result1
            // 
            this.pb_Result1.Image = ((System.Drawing.Image)(resources.GetObject("pb_Result1.Image")));
            this.pb_Result1.Location = new System.Drawing.Point(34, 23);
            this.pb_Result1.Name = "pb_Result1";
            this.pb_Result1.Size = new System.Drawing.Size(125, 176);
            this.pb_Result1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Result1.TabIndex = 14;
            this.pb_Result1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Location = new System.Drawing.Point(481, 527);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(110, 8);
            this.panel1.TabIndex = 24;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lime;
            this.panel2.Location = new System.Drawing.Point(590, 527);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(91, 8);
            this.panel2.TabIndex = 25;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gold;
            this.panel5.Location = new System.Drawing.Point(677, 527);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(72, 8);
            this.panel5.TabIndex = 26;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Red;
            this.panel3.Location = new System.Drawing.Point(742, 527);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(135, 8);
            this.panel3.TabIndex = 27;
            // 
            // trb_BMI
            // 
            this.trb_BMI.AccessibleRole = System.Windows.Forms.AccessibleRole.Window;
            this.trb_BMI.BackColor = System.Drawing.SystemColors.Control;
            this.trb_BMI.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.trb_BMI.Location = new System.Drawing.Point(479, 490);
            this.trb_BMI.Maximum = 40;
            this.trb_BMI.Minimum = 10;
            this.trb_BMI.Name = "trb_BMI";
            this.trb_BMI.Size = new System.Drawing.Size(400, 45);
            this.trb_BMI.TabIndex = 23;
            this.trb_BMI.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trb_BMI.Value = 10;
            // 
            // l_BMI
            // 
            this.l_BMI.AutoSize = true;
            this.l_BMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_BMI.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_BMI.Location = new System.Drawing.Point(475, 462);
            this.l_BMI.Name = "l_BMI";
            this.l_BMI.Size = new System.Drawing.Size(49, 25);
            this.l_BMI.TabIndex = 28;
            this.l_BMI.Text = "BMI";
            // 
            // l_Underweight
            // 
            this.l_Underweight.AutoSize = true;
            this.l_Underweight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Underweight.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Underweight.Location = new System.Drawing.Point(477, 538);
            this.l_Underweight.Name = "l_Underweight";
            this.l_Underweight.Size = new System.Drawing.Size(100, 15);
            this.l_Underweight.TabIndex = 29;
            this.l_Underweight.Text = "Недостаточный";
            // 
            // l_Healthy
            // 
            this.l_Healthy.AutoSize = true;
            this.l_Healthy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Healthy.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Healthy.Location = new System.Drawing.Point(601, 538);
            this.l_Healthy.Name = "l_Healthy";
            this.l_Healthy.Size = new System.Drawing.Size(66, 15);
            this.l_Healthy.TabIndex = 31;
            this.l_Healthy.Text = "Здоровый";
            // 
            // l_Over
            // 
            this.l_Over.AutoSize = true;
            this.l_Over.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Over.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Over.Location = new System.Drawing.Point(674, 538);
            this.l_Over.Name = "l_Over";
            this.l_Over.Size = new System.Drawing.Size(81, 15);
            this.l_Over.TabIndex = 32;
            this.l_Over.Text = "Избыточный";
            // 
            // l_Obese
            // 
            this.l_Obese.AutoSize = true;
            this.l_Obese.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Obese.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Obese.Location = new System.Drawing.Point(777, 538);
            this.l_Obese.Name = "l_Obese";
            this.l_Obese.Size = new System.Drawing.Size(67, 15);
            this.l_Obese.TabIndex = 33;
            this.l_Obese.Text = "Ожирение";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Back.FlatAppearance.BorderSize = 0;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Back.Location = new System.Drawing.Point(30, 22);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Назад";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // BMI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.l_Obese);
            this.Controls.Add(this.l_Over);
            this.Controls.Add(this.l_Healthy);
            this.Controls.Add(this.l_Underweight);
            this.Controls.Add(this.l_BMI);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.trb_BMI);
            this.Controls.Add(this.pnl_Result);
            this.Controls.Add(this.pnl_Female);
            this.Controls.Add(this.pnl_Male);
            this.Controls.Add(this.pnl_Down);
            this.Controls.Add(this.pnl_Up);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_Calculate);
            this.Controls.Add(this.l_Kg);
            this.Controls.Add(this.l_Cm);
            this.Controls.Add(this.tb_Weight);
            this.Controls.Add(this.tb_Height);
            this.Controls.Add(this.l_Weight);
            this.Controls.Add(this.l_Height);
            this.Controls.Add(this.l_BMICalculator);
            this.Name = "BMI";
            this.Text = "BMI";
            this.Load += new System.EventHandler(this.BMI_Load);
            this.pnl_Down.ResumeLayout(false);
            this.pnl_Down.PerformLayout();
            this.pnl_Up.ResumeLayout(false);
            this.pnl_Up.PerformLayout();
            this.pnl_Male.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Male)).EndInit();
            this.pnl_Female.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Female)).EndInit();
            this.pnl_Result.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Result1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trb_BMI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label l_BMICalculator;
        private System.Windows.Forms.Label l_Height;
        private System.Windows.Forms.Label l_Weight;
        private System.Windows.Forms.TextBox tb_Height;
        private System.Windows.Forms.TextBox tb_Weight;
        private System.Windows.Forms.Label l_Kg;
        private System.Windows.Forms.Label l_Cm;
        private System.Windows.Forms.Button btn_Calculate;
        private System.Windows.Forms.Button btn_Cancel;
        public System.Windows.Forms.Panel pnl_Down;
        public System.Windows.Forms.Label l_Count;
        public System.Windows.Forms.Panel pnl_Up;
        public System.Windows.Forms.Label l_MarathonSkills;
        private System.Windows.Forms.Panel pnl_Male;
        private System.Windows.Forms.PictureBox pb_Male;
        private System.Windows.Forms.Label l_Male;
        private System.Windows.Forms.Panel pnl_Female;
        private System.Windows.Forms.Label l_Female;
        private System.Windows.Forms.PictureBox pb_Female;
        private System.Windows.Forms.Panel pnl_Result;
        private System.Windows.Forms.Label l_Result;
        private System.Windows.Forms.PictureBox pb_Result1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TrackBar trb_BMI;
        public System.Windows.Forms.Label l_BMI;
        private System.Windows.Forms.PictureBox pb_Result2;
        private System.Windows.Forms.PictureBox pb_Result3;
        private System.Windows.Forms.PictureBox pb_Result4;
        public System.Windows.Forms.Label l_Underweight;
        public System.Windows.Forms.Label l_Healthy;
        public System.Windows.Forms.Label l_Over;
        public System.Windows.Forms.Label l_Obese;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button btn_Back;
    }
}