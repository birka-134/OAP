﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОАП_ПР___25_26__WS_
{
    public partial class Time : Form
    {
        public Time()
        {
            InitializeComponent();
        }
        public string TimeCount(double Speed)
        {
            double time = 42 / Speed;
            string strTime = time + "h";
            if (time < 1)
            {
                time = Math.Round(time * 60,1);
                strTime = time + " min";
            }
            return strTime;
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pb_F1Car_Click(object sender, EventArgs e)
        {
            double speed = 345;
            l_ItemName.Text = l_F1Car.Text;
            pb_ItemPhoto.Image = pb_F1Car.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed +" km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_Worm_Click(object sender, EventArgs e)
        {
            double speed = 0.03;
            l_ItemName.Text = l_Worm.Text;
            pb_ItemPhoto.Image = pb_Worm.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed + " km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_Sloth_Click(object sender, EventArgs e)
        {
            double speed = 0.12;
            l_ItemName.Text = l_Sloth.Text;
            pb_ItemPhoto.Image = pb_Sloth.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed + " km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_Capybara_Click(object sender, EventArgs e)
        {
            double speed = 35;
            l_ItemName.Text = l_Capybara.Text;
            pb_ItemPhoto.Image = pb_Capybara.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed + " km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_Jaguar_Click(object sender, EventArgs e)
        {
            double speed = 80;
            l_ItemName.Text = l_Jaguar.Text;
            pb_ItemPhoto.Image = pb_Jaguar.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed + " km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_Slug_Click(object sender, EventArgs e)
        {
            double speed = 0.01;
            l_ItemName.Text = l_Slug.Text;
            pb_ItemPhoto.Image = pb_Slug.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed + " km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_Horse_Click(object sender, EventArgs e)
        {
            double speed = 15;
            l_ItemName.Text = l_Horse.Text;
            pb_ItemPhoto.Image = pb_Horse.Image;
            l_Inf.Text = "Максимальная скорость " + l_ItemName.Text + " " + speed + " km/h. Это займет " + TimeCount(speed) + ", чтобы завершить 42km марафон";
            pnl_Item.Visible = true;
        }

        private void pb_AirbusA380_Click(object sender, EventArgs e)
        {
            double length = 73;
            double quantity = Math.Round(42000 / length, 1);
            l_ItemName.Text = l_AirbusA380.Text;
            pb_ItemPhoto.Image = pb_AirbusA380.Image;
            l_Inf.Text = "Длина " + l_ItemName.Text + " " + length + " m. Это займет " + quantity + " из них, чтобы покрыть расстояние в 42km марафона";
            pnl_Item.Visible = true;
        }

        private void pb_Havaianas_Click(object sender, EventArgs e)
        {
            double length = 0.245;
            double quantity = Math.Round(42000 / length, 1);
            l_ItemName.Text = l_Havaianas.Text;
            pb_ItemPhoto.Image = pb_Havaianas.Image;
            l_Inf.Text = "Длина " + l_ItemName.Text + " " + length + " m. Это займет " + quantity + " из них, чтобы покрыть расстояние в 42km марафона";
            pnl_Item.Visible = true;
        }

        private void pb_FootballField_Click(object sender, EventArgs e)
        {
            double length = 105;
            double quantity = Math.Round(42000 / length, 1);
            l_ItemName.Text = l_FootballField.Text;
            pb_ItemPhoto.Image = pb_FootballField.Image;
            l_Inf.Text = "Длина " + l_ItemName.Text + " " + length + " m. Это займет " + quantity + " из них, чтобы покрыть расстояние в 42km марафона";
            pnl_Item.Visible = true;
        }

        private void pb_Ronaldinho_Click(object sender, EventArgs e)
        {
            double length = 1.81;
            double quantity = Math.Round(42000 / length, 1);
            l_ItemName.Text = l_Ronaldinho.Text;
            pb_ItemPhoto.Image = pb_Ronaldinho.Image;
            l_Inf.Text = "Длина " + l_ItemName.Text + " " + length + " m. Это займет " + quantity + " из них, чтобы покрыть расстояние в 42km марафона";
            pnl_Item.Visible = true;
        }

        private void pb_Bus_Click(object sender, EventArgs e)
        {
            double length = 10;
            double quantity = Math.Round(42000 / length, 1);
            l_ItemName.Text = l_Bus.Text;
            pb_ItemPhoto.Image = pb_Bus.Image;
            l_Inf.Text = "Длина " + l_ItemName.Text + " " + length + " m. Это займет " + quantity + " из них, чтобы покрыть расстояние в 42km марафона";
            pnl_Item.Visible = true;
        }

        public DateTime endDate;
        private void Time_Load(object sender, EventArgs e)
        {
            RoundedButton.RoundButton(btn_Back, 10); 
            
            endDate = new DateTime(2022, 5, 11, 8, 30, 0);
            timer.Start();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            l_Count.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", endDate - DateTime.Now);
        }
    }
}
