﻿
namespace ОАП_ПР___25_26__WS_
{
    partial class Map
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Map));
            this.l_Checkpoint = new System.Windows.Forms.Label();
            this.pnl_Down = new System.Windows.Forms.Panel();
            this.l_Count = new System.Windows.Forms.Label();
            this.pnl_Up = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.l_MarathonSkills = new System.Windows.Forms.Label();
            this.pnl_InfoCheckpoint = new System.Windows.Forms.Panel();
            this.pb_Medical = new System.Windows.Forms.PictureBox();
            this.pb_Information = new System.Windows.Forms.PictureBox();
            this.pb_Toilets = new System.Windows.Forms.PictureBox();
            this.pb_EnergyBars = new System.Windows.Forms.PictureBox();
            this.pb_Drinks = new System.Windows.Forms.PictureBox();
            this.pb_CloseInfo = new System.Windows.Forms.PictureBox();
            this.l_Features = new System.Windows.Forms.Label();
            this.pb_InteractMap = new System.Windows.Forms.PictureBox();
            this.btn_Check1 = new System.Windows.Forms.Button();
            this.btn_Check2 = new System.Windows.Forms.Button();
            this.btn_Check3 = new System.Windows.Forms.Button();
            this.btn_Check4 = new System.Windows.Forms.Button();
            this.btn_Check5 = new System.Windows.Forms.Button();
            this.btn_Check6 = new System.Windows.Forms.Button();
            this.btn_Full = new System.Windows.Forms.Button();
            this.btn_Fun = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.btn_Half = new System.Windows.Forms.Button();
            this.pnl_Down.SuspendLayout();
            this.pnl_Up.SuspendLayout();
            this.pnl_InfoCheckpoint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Medical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Information)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Toilets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_EnergyBars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Drinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_CloseInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_InteractMap)).BeginInit();
            this.SuspendLayout();
            // 
            // l_Checkpoint
            // 
            this.l_Checkpoint.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Checkpoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Checkpoint.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Checkpoint.Location = new System.Drawing.Point(11, 17);
            this.l_Checkpoint.Name = "l_Checkpoint";
            this.l_Checkpoint.Size = new System.Drawing.Size(195, 22);
            this.l_Checkpoint.TabIndex = 6;
            this.l_Checkpoint.Text = "label1";
            // 
            // pnl_Down
            // 
            this.pnl_Down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Down.Controls.Add(this.l_Count);
            this.pnl_Down.Location = new System.Drawing.Point(-1, 624);
            this.pnl_Down.Name = "pnl_Down";
            this.pnl_Down.Size = new System.Drawing.Size(886, 39);
            this.pnl_Down.TabIndex = 8;
            // 
            // l_Count
            // 
            this.l_Count.AutoSize = true;
            this.l_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Count.ForeColor = System.Drawing.SystemColors.Window;
            this.l_Count.Location = new System.Drawing.Point(306, 12);
            this.l_Count.Name = "l_Count";
            this.l_Count.Size = new System.Drawing.Size(340, 16);
            this.l_Count.TabIndex = 1;
            this.l_Count.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // pnl_Up
            // 
            this.pnl_Up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Up.Controls.Add(this.btn_Back);
            this.pnl_Up.Controls.Add(this.l_MarathonSkills);
            this.pnl_Up.Location = new System.Drawing.Point(-1, -3);
            this.pnl_Up.Name = "pnl_Up";
            this.pnl_Up.Size = new System.Drawing.Size(886, 60);
            this.pnl_Up.TabIndex = 7;
            // 
            // btn_Back
            // 
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Back.Location = new System.Drawing.Point(30, 22);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Назад";
            this.btn_Back.UseVisualStyleBackColor = true;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // l_MarathonSkills
            // 
            this.l_MarathonSkills.AutoSize = true;
            this.l_MarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MarathonSkills.ForeColor = System.Drawing.SystemColors.Window;
            this.l_MarathonSkills.Location = new System.Drawing.Point(135, 14);
            this.l_MarathonSkills.Name = "l_MarathonSkills";
            this.l_MarathonSkills.Size = new System.Drawing.Size(336, 31);
            this.l_MarathonSkills.TabIndex = 0;
            this.l_MarathonSkills.Text = "MARATHON SKILLS 2016";
            // 
            // pnl_InfoCheckpoint
            // 
            this.pnl_InfoCheckpoint.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_Medical);
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_Information);
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_Toilets);
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_EnergyBars);
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_Drinks);
            this.pnl_InfoCheckpoint.Controls.Add(this.pb_CloseInfo);
            this.pnl_InfoCheckpoint.Controls.Add(this.l_Features);
            this.pnl_InfoCheckpoint.Controls.Add(this.l_Checkpoint);
            this.pnl_InfoCheckpoint.Location = new System.Drawing.Point(584, 85);
            this.pnl_InfoCheckpoint.Name = "pnl_InfoCheckpoint";
            this.pnl_InfoCheckpoint.Size = new System.Drawing.Size(273, 216);
            this.pnl_InfoCheckpoint.TabIndex = 9;
            this.pnl_InfoCheckpoint.Visible = false;
            // 
            // pb_Medical
            // 
            this.pb_Medical.Image = ((System.Drawing.Image)(resources.GetObject("pb_Medical.Image")));
            this.pb_Medical.Location = new System.Drawing.Point(16, 174);
            this.pb_Medical.Name = "pb_Medical";
            this.pb_Medical.Size = new System.Drawing.Size(25, 25);
            this.pb_Medical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Medical.TabIndex = 25;
            this.pb_Medical.TabStop = false;
            // 
            // pb_Information
            // 
            this.pb_Information.Image = ((System.Drawing.Image)(resources.GetObject("pb_Information.Image")));
            this.pb_Information.Location = new System.Drawing.Point(16, 143);
            this.pb_Information.Name = "pb_Information";
            this.pb_Information.Size = new System.Drawing.Size(25, 25);
            this.pb_Information.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Information.TabIndex = 24;
            this.pb_Information.TabStop = false;
            // 
            // pb_Toilets
            // 
            this.pb_Toilets.Image = ((System.Drawing.Image)(resources.GetObject("pb_Toilets.Image")));
            this.pb_Toilets.Location = new System.Drawing.Point(16, 112);
            this.pb_Toilets.Name = "pb_Toilets";
            this.pb_Toilets.Size = new System.Drawing.Size(25, 25);
            this.pb_Toilets.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Toilets.TabIndex = 23;
            this.pb_Toilets.TabStop = false;
            // 
            // pb_EnergyBars
            // 
            this.pb_EnergyBars.Image = ((System.Drawing.Image)(resources.GetObject("pb_EnergyBars.Image")));
            this.pb_EnergyBars.Location = new System.Drawing.Point(16, 81);
            this.pb_EnergyBars.Name = "pb_EnergyBars";
            this.pb_EnergyBars.Size = new System.Drawing.Size(25, 25);
            this.pb_EnergyBars.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_EnergyBars.TabIndex = 22;
            this.pb_EnergyBars.TabStop = false;
            // 
            // pb_Drinks
            // 
            this.pb_Drinks.Image = ((System.Drawing.Image)(resources.GetObject("pb_Drinks.Image")));
            this.pb_Drinks.Location = new System.Drawing.Point(16, 50);
            this.pb_Drinks.Name = "pb_Drinks";
            this.pb_Drinks.Size = new System.Drawing.Size(25, 25);
            this.pb_Drinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Drinks.TabIndex = 21;
            this.pb_Drinks.TabStop = false;
            // 
            // pb_CloseInfo
            // 
            this.pb_CloseInfo.Image = ((System.Drawing.Image)(resources.GetObject("pb_CloseInfo.Image")));
            this.pb_CloseInfo.Location = new System.Drawing.Point(246, 16);
            this.pb_CloseInfo.Name = "pb_CloseInfo";
            this.pb_CloseInfo.Size = new System.Drawing.Size(15, 15);
            this.pb_CloseInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_CloseInfo.TabIndex = 20;
            this.pb_CloseInfo.TabStop = false;
            this.pb_CloseInfo.Click += new System.EventHandler(this.pb_CloseInfo_Click);
            // 
            // l_Features
            // 
            this.l_Features.BackColor = System.Drawing.SystemColors.ControlLight;
            this.l_Features.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Features.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Features.Location = new System.Drawing.Point(57, 50);
            this.l_Features.Name = "l_Features";
            this.l_Features.Size = new System.Drawing.Size(204, 150);
            this.l_Features.TabIndex = 7;
            this.l_Features.Text = "label1";
            // 
            // pb_InteractMap
            // 
            this.pb_InteractMap.Image = ((System.Drawing.Image)(resources.GetObject("pb_InteractMap.Image")));
            this.pb_InteractMap.Location = new System.Drawing.Point(29, 84);
            this.pb_InteractMap.Name = "pb_InteractMap";
            this.pb_InteractMap.Size = new System.Drawing.Size(515, 508);
            this.pb_InteractMap.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_InteractMap.TabIndex = 10;
            this.pb_InteractMap.TabStop = false;
            // 
            // btn_Check1
            // 
            this.btn_Check1.BackColor = System.Drawing.Color.Yellow;
            this.btn_Check1.FlatAppearance.BorderSize = 0;
            this.btn_Check1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Check1.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_Check1.Location = new System.Drawing.Point(483, 98);
            this.btn_Check1.Name = "btn_Check1";
            this.btn_Check1.Size = new System.Drawing.Size(30, 30);
            this.btn_Check1.TabIndex = 11;
            this.btn_Check1.Text = "1";
            this.btn_Check1.UseVisualStyleBackColor = false;
            this.btn_Check1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_Check2
            // 
            this.btn_Check2.BackColor = System.Drawing.Color.Yellow;
            this.btn_Check2.FlatAppearance.BorderSize = 0;
            this.btn_Check2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Check2.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_Check2.Location = new System.Drawing.Point(289, 312);
            this.btn_Check2.Name = "btn_Check2";
            this.btn_Check2.Size = new System.Drawing.Size(30, 30);
            this.btn_Check2.TabIndex = 12;
            this.btn_Check2.Text = "2";
            this.btn_Check2.UseVisualStyleBackColor = false;
            this.btn_Check2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_Check3
            // 
            this.btn_Check3.BackColor = System.Drawing.Color.Yellow;
            this.btn_Check3.FlatAppearance.BorderSize = 0;
            this.btn_Check3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Check3.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_Check3.Location = new System.Drawing.Point(479, 456);
            this.btn_Check3.Name = "btn_Check3";
            this.btn_Check3.Size = new System.Drawing.Size(30, 30);
            this.btn_Check3.TabIndex = 13;
            this.btn_Check3.Text = "3";
            this.btn_Check3.UseVisualStyleBackColor = false;
            this.btn_Check3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_Check4
            // 
            this.btn_Check4.BackColor = System.Drawing.Color.Yellow;
            this.btn_Check4.FlatAppearance.BorderSize = 0;
            this.btn_Check4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Check4.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_Check4.Location = new System.Drawing.Point(224, 546);
            this.btn_Check4.Name = "btn_Check4";
            this.btn_Check4.Size = new System.Drawing.Size(30, 30);
            this.btn_Check4.TabIndex = 14;
            this.btn_Check4.Text = "4";
            this.btn_Check4.UseVisualStyleBackColor = false;
            this.btn_Check4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_Check5
            // 
            this.btn_Check5.BackColor = System.Drawing.Color.Yellow;
            this.btn_Check5.FlatAppearance.BorderSize = 0;
            this.btn_Check5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Check5.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_Check5.Location = new System.Drawing.Point(126, 261);
            this.btn_Check5.Name = "btn_Check5";
            this.btn_Check5.Size = new System.Drawing.Size(30, 30);
            this.btn_Check5.TabIndex = 15;
            this.btn_Check5.Text = "5";
            this.btn_Check5.UseVisualStyleBackColor = false;
            this.btn_Check5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_Check6
            // 
            this.btn_Check6.BackColor = System.Drawing.Color.Yellow;
            this.btn_Check6.FlatAppearance.BorderSize = 0;
            this.btn_Check6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Check6.ForeColor = System.Drawing.Color.DarkOrange;
            this.btn_Check6.Location = new System.Drawing.Point(77, 99);
            this.btn_Check6.Name = "btn_Check6";
            this.btn_Check6.Size = new System.Drawing.Size(30, 30);
            this.btn_Check6.TabIndex = 16;
            this.btn_Check6.Text = "6";
            this.btn_Check6.UseVisualStyleBackColor = false;
            this.btn_Check6.Click += new System.EventHandler(this.button6_Click);
            // 
            // btn_Full
            // 
            this.btn_Full.BackColor = System.Drawing.Color.LightBlue;
            this.btn_Full.FlatAppearance.BorderSize = 0;
            this.btn_Full.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Full.Location = new System.Drawing.Point(292, 106);
            this.btn_Full.Name = "btn_Full";
            this.btn_Full.Size = new System.Drawing.Size(75, 23);
            this.btn_Full.TabIndex = 17;
            this.btn_Full.Text = "Start";
            this.btn_Full.UseVisualStyleBackColor = false;
            this.btn_Full.Click += new System.EventHandler(this.button7_Click);
            // 
            // btn_Fun
            // 
            this.btn_Fun.BackColor = System.Drawing.Color.LightBlue;
            this.btn_Fun.FlatAppearance.BorderSize = 0;
            this.btn_Fun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Fun.Location = new System.Drawing.Point(57, 233);
            this.btn_Fun.Name = "btn_Fun";
            this.btn_Fun.Size = new System.Drawing.Size(75, 23);
            this.btn_Fun.TabIndex = 18;
            this.btn_Fun.Text = "Start";
            this.btn_Fun.UseVisualStyleBackColor = false;
            this.btn_Fun.Click += new System.EventHandler(this.button8_Click);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // btn_Half
            // 
            this.btn_Half.BackColor = System.Drawing.Color.LightBlue;
            this.btn_Half.FlatAppearance.BorderSize = 0;
            this.btn_Half.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Half.Location = new System.Drawing.Point(292, 552);
            this.btn_Half.Name = "btn_Half";
            this.btn_Half.Size = new System.Drawing.Size(75, 23);
            this.btn_Half.TabIndex = 19;
            this.btn_Half.Text = "Start";
            this.btn_Half.UseVisualStyleBackColor = false;
            this.btn_Half.Click += new System.EventHandler(this.button9_Click);
            // 
            // Map
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.btn_Half);
            this.Controls.Add(this.btn_Fun);
            this.Controls.Add(this.btn_Full);
            this.Controls.Add(this.btn_Check6);
            this.Controls.Add(this.btn_Check5);
            this.Controls.Add(this.btn_Check4);
            this.Controls.Add(this.btn_Check3);
            this.Controls.Add(this.btn_Check2);
            this.Controls.Add(this.btn_Check1);
            this.Controls.Add(this.pb_InteractMap);
            this.Controls.Add(this.pnl_InfoCheckpoint);
            this.Controls.Add(this.pnl_Down);
            this.Controls.Add(this.pnl_Up);
            this.Name = "Map";
            this.Text = "Map";
            this.Load += new System.EventHandler(this.Map_Load);
            this.pnl_Down.ResumeLayout(false);
            this.pnl_Down.PerformLayout();
            this.pnl_Up.ResumeLayout(false);
            this.pnl_Up.PerformLayout();
            this.pnl_InfoCheckpoint.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Medical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Information)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Toilets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_EnergyBars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Drinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_CloseInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_InteractMap)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label l_Checkpoint;
        public System.Windows.Forms.Panel pnl_Down;
        public System.Windows.Forms.Label l_Count;
        public System.Windows.Forms.Panel pnl_Up;
        private System.Windows.Forms.Button btn_Back;
        public System.Windows.Forms.Label l_MarathonSkills;
        private System.Windows.Forms.Panel pnl_InfoCheckpoint;
        private System.Windows.Forms.PictureBox pb_InteractMap;
        private System.Windows.Forms.Button btn_Check1;
        private System.Windows.Forms.Button btn_Check2;
        private System.Windows.Forms.Button btn_Check3;
        private System.Windows.Forms.Button btn_Check4;
        private System.Windows.Forms.Button btn_Check5;
        private System.Windows.Forms.Button btn_Check6;
        private System.Windows.Forms.Label l_Features;
        private System.Windows.Forms.Button btn_Full;
        private System.Windows.Forms.Button btn_Fun;
        private System.Windows.Forms.PictureBox pb_CloseInfo;
        private System.Windows.Forms.PictureBox pb_Drinks;
        private System.Windows.Forms.PictureBox pb_Medical;
        private System.Windows.Forms.PictureBox pb_Information;
        private System.Windows.Forms.PictureBox pb_Toilets;
        private System.Windows.Forms.PictureBox pb_EnergyBars;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button btn_Half;
    }
}