﻿
namespace ОАП_ПР___25_26__WS_
{
    partial class Menu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btn_MarathonSkills = new System.Windows.Forms.Button();
            this.btn_BMI = new System.Windows.Forms.Button();
            this.btn_BMR = new System.Windows.Forms.Button();
            this.btn_Time = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_Down = new System.Windows.Forms.Panel();
            this.l_Count = new System.Windows.Forms.Label();
            this.pnl_Up = new System.Windows.Forms.Panel();
            this.l_MarathonSkills = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pnl_Down.SuspendLayout();
            this.pnl_Up.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_MarathonSkills
            // 
            this.btn_MarathonSkills.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_MarathonSkills.FlatAppearance.BorderSize = 0;
            this.btn_MarathonSkills.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MarathonSkills.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_MarathonSkills.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_MarathonSkills.Location = new System.Drawing.Point(148, 227);
            this.btn_MarathonSkills.Name = "btn_MarathonSkills";
            this.btn_MarathonSkills.Size = new System.Drawing.Size(258, 98);
            this.btn_MarathonSkills.TabIndex = 5;
            this.btn_MarathonSkills.Text = "Marathon Skills 2016";
            this.btn_MarathonSkills.UseVisualStyleBackColor = false;
            this.btn_MarathonSkills.Click += new System.EventHandler(this.btn_MarathonSkills_Click);
            // 
            // btn_BMI
            // 
            this.btn_BMI.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_BMI.FlatAppearance.BorderSize = 0;
            this.btn_BMI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BMI.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_BMI.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_BMI.Location = new System.Drawing.Point(148, 386);
            this.btn_BMI.Name = "btn_BMI";
            this.btn_BMI.Size = new System.Drawing.Size(258, 98);
            this.btn_BMI.TabIndex = 6;
            this.btn_BMI.Text = "BMI калькулятор";
            this.btn_BMI.UseVisualStyleBackColor = false;
            this.btn_BMI.Click += new System.EventHandler(this.btn_BMI_Click);
            // 
            // btn_BMR
            // 
            this.btn_BMR.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_BMR.FlatAppearance.BorderSize = 0;
            this.btn_BMR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_BMR.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_BMR.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_BMR.Location = new System.Drawing.Point(507, 386);
            this.btn_BMR.Name = "btn_BMR";
            this.btn_BMR.Size = new System.Drawing.Size(258, 98);
            this.btn_BMR.TabIndex = 8;
            this.btn_BMR.Text = "BMR калькулятор";
            this.btn_BMR.UseVisualStyleBackColor = false;
            this.btn_BMR.Click += new System.EventHandler(this.btn_BMR_Click);
            // 
            // btn_Time
            // 
            this.btn_Time.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Time.FlatAppearance.BorderSize = 0;
            this.btn_Time.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Time.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Time.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn_Time.Location = new System.Drawing.Point(507, 227);
            this.btn_Time.Name = "btn_Time";
            this.btn_Time.Size = new System.Drawing.Size(258, 98);
            this.btn_Time.TabIndex = 7;
            this.btn_Time.Text = "Насколько долгий марафон";
            this.btn_Time.UseVisualStyleBackColor = false;
            this.btn_Time.Click += new System.EventHandler(this.btn_Time_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(121, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(534, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "ИНФОРМАЦИЯ О MARATHON SKILLS 2016";
            // 
            // pnl_Down
            // 
            this.pnl_Down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Down.Controls.Add(this.l_Count);
            this.pnl_Down.Location = new System.Drawing.Point(-1, 623);
            this.pnl_Down.Name = "pnl_Down";
            this.pnl_Down.Size = new System.Drawing.Size(884, 39);
            this.pnl_Down.TabIndex = 10;
            // 
            // l_Count
            // 
            this.l_Count.AutoSize = true;
            this.l_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Count.ForeColor = System.Drawing.SystemColors.Window;
            this.l_Count.Location = new System.Drawing.Point(283, 13);
            this.l_Count.Name = "l_Count";
            this.l_Count.Size = new System.Drawing.Size(340, 16);
            this.l_Count.TabIndex = 1;
            this.l_Count.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // pnl_Up
            // 
            this.pnl_Up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Up.Controls.Add(this.l_MarathonSkills);
            this.pnl_Up.Location = new System.Drawing.Point(-1, -3);
            this.pnl_Up.Name = "pnl_Up";
            this.pnl_Up.Size = new System.Drawing.Size(884, 60);
            this.pnl_Up.TabIndex = 9;
            // 
            // l_MarathonSkills
            // 
            this.l_MarathonSkills.AutoSize = true;
            this.l_MarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MarathonSkills.ForeColor = System.Drawing.SystemColors.Window;
            this.l_MarathonSkills.Location = new System.Drawing.Point(134, 12);
            this.l_MarathonSkills.Name = "l_MarathonSkills";
            this.l_MarathonSkills.Size = new System.Drawing.Size(336, 31);
            this.l_MarathonSkills.TabIndex = 0;
            this.l_MarathonSkills.Text = "MARATHON SKILLS 2016";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.pnl_Down);
            this.Controls.Add(this.pnl_Up);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_BMR);
            this.Controls.Add(this.btn_Time);
            this.Controls.Add(this.btn_BMI);
            this.Controls.Add(this.btn_MarathonSkills);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.pnl_Down.ResumeLayout(false);
            this.pnl_Down.PerformLayout();
            this.pnl_Up.ResumeLayout(false);
            this.pnl_Up.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_MarathonSkills;
        private System.Windows.Forms.Button btn_BMI;
        private System.Windows.Forms.Button btn_BMR;
        private System.Windows.Forms.Button btn_Time;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Panel pnl_Down;
        public System.Windows.Forms.Label l_Count;
        public System.Windows.Forms.Panel pnl_Up;
        public System.Windows.Forms.Label l_MarathonSkills;
        private System.Windows.Forms.Timer timer;
    }
}

