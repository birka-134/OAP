﻿
namespace ОАП_ПР___25_26__WS_
{
    partial class Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Info));
            this.pnl_Down = new System.Windows.Forms.Panel();
            this.l_Count = new System.Windows.Forms.Label();
            this.pnl_Up = new System.Windows.Forms.Panel();
            this.btn_Back = new System.Windows.Forms.Button();
            this.l_MarathonSkills = new System.Windows.Forms.Label();
            this.l_InfoMarathonSkills = new System.Windows.Forms.Label();
            this.l_Info = new System.Windows.Forms.Label();
            this.pb_InteractMap = new System.Windows.Forms.PictureBox();
            this.pb_Marathon = new System.Windows.Forms.PictureBox();
            this.pb_ParkLake = new System.Windows.Forms.PictureBox();
            this.pb_TeatroMunicipal = new System.Windows.Forms.PictureBox();
            this.pb_BancoBanespa = new System.Windows.Forms.PictureBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pnl_Down.SuspendLayout();
            this.pnl_Up.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_InteractMap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Marathon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ParkLake)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_TeatroMunicipal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_BancoBanespa)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_Down
            // 
            this.pnl_Down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Down.Controls.Add(this.l_Count);
            this.pnl_Down.Location = new System.Drawing.Point(-1, 624);
            this.pnl_Down.Name = "pnl_Down";
            this.pnl_Down.Size = new System.Drawing.Size(886, 39);
            this.pnl_Down.TabIndex = 3;
            // 
            // l_Count
            // 
            this.l_Count.AutoSize = true;
            this.l_Count.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Count.ForeColor = System.Drawing.SystemColors.Window;
            this.l_Count.Location = new System.Drawing.Point(306, 12);
            this.l_Count.Name = "l_Count";
            this.l_Count.Size = new System.Drawing.Size(340, 16);
            this.l_Count.TabIndex = 1;
            this.l_Count.Text = "{0} дней {1}  часов и {2} минут до старта марафона!";
            // 
            // pnl_Up
            // 
            this.pnl_Up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.pnl_Up.Controls.Add(this.btn_Back);
            this.pnl_Up.Controls.Add(this.l_MarathonSkills);
            this.pnl_Up.Location = new System.Drawing.Point(-1, -3);
            this.pnl_Up.Name = "pnl_Up";
            this.pnl_Up.Size = new System.Drawing.Size(886, 60);
            this.pnl_Up.TabIndex = 2;
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_Back.FlatAppearance.BorderSize = 0;
            this.btn_Back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Back.Location = new System.Drawing.Point(30, 22);
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.Size = new System.Drawing.Size(75, 23);
            this.btn_Back.TabIndex = 1;
            this.btn_Back.Text = "Назад";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // l_MarathonSkills
            // 
            this.l_MarathonSkills.AutoSize = true;
            this.l_MarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_MarathonSkills.ForeColor = System.Drawing.SystemColors.Window;
            this.l_MarathonSkills.Location = new System.Drawing.Point(135, 14);
            this.l_MarathonSkills.Name = "l_MarathonSkills";
            this.l_MarathonSkills.Size = new System.Drawing.Size(336, 31);
            this.l_MarathonSkills.TabIndex = 0;
            this.l_MarathonSkills.Text = "MARATHON SKILLS 2016";
            // 
            // l_InfoMarathonSkills
            // 
            this.l_InfoMarathonSkills.AutoSize = true;
            this.l_InfoMarathonSkills.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_InfoMarathonSkills.ForeColor = System.Drawing.SystemColors.InfoText;
            this.l_InfoMarathonSkills.Location = new System.Drawing.Point(247, 70);
            this.l_InfoMarathonSkills.Name = "l_InfoMarathonSkills";
            this.l_InfoMarathonSkills.Size = new System.Drawing.Size(415, 29);
            this.l_InfoMarathonSkills.TabIndex = 4;
            this.l_InfoMarathonSkills.Text = "Информация о Marathon Skills 2016";
            // 
            // l_Info
            // 
            this.l_Info.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l_Info.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.l_Info.Location = new System.Drawing.Point(345, 121);
            this.l_Info.Name = "l_Info";
            this.l_Info.Size = new System.Drawing.Size(510, 480);
            this.l_Info.TabIndex = 5;
            this.l_Info.Text = "label1";
            // 
            // pb_InteractMap
            // 
            this.pb_InteractMap.Image = ((System.Drawing.Image)(resources.GetObject("pb_InteractMap.Image")));
            this.pb_InteractMap.Location = new System.Drawing.Point(77, 121);
            this.pb_InteractMap.Name = "pb_InteractMap";
            this.pb_InteractMap.Size = new System.Drawing.Size(200, 200);
            this.pb_InteractMap.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_InteractMap.TabIndex = 6;
            this.pb_InteractMap.TabStop = false;
            this.pb_InteractMap.Click += new System.EventHandler(this.pb_InteractMap_Click);
            // 
            // pb_Marathon
            // 
            this.pb_Marathon.Image = ((System.Drawing.Image)(resources.GetObject("pb_Marathon.Image")));
            this.pb_Marathon.Location = new System.Drawing.Point(12, 343);
            this.pb_Marathon.Name = "pb_Marathon";
            this.pb_Marathon.Size = new System.Drawing.Size(150, 112);
            this.pb_Marathon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Marathon.TabIndex = 7;
            this.pb_Marathon.TabStop = false;
            // 
            // pb_ParkLake
            // 
            this.pb_ParkLake.Image = ((System.Drawing.Image)(resources.GetObject("pb_ParkLake.Image")));
            this.pb_ParkLake.Location = new System.Drawing.Point(180, 343);
            this.pb_ParkLake.Name = "pb_ParkLake";
            this.pb_ParkLake.Size = new System.Drawing.Size(150, 112);
            this.pb_ParkLake.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_ParkLake.TabIndex = 8;
            this.pb_ParkLake.TabStop = false;
            // 
            // pb_TeatroMunicipal
            // 
            this.pb_TeatroMunicipal.Image = ((System.Drawing.Image)(resources.GetObject("pb_TeatroMunicipal.Image")));
            this.pb_TeatroMunicipal.Location = new System.Drawing.Point(180, 473);
            this.pb_TeatroMunicipal.Name = "pb_TeatroMunicipal";
            this.pb_TeatroMunicipal.Size = new System.Drawing.Size(150, 112);
            this.pb_TeatroMunicipal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_TeatroMunicipal.TabIndex = 10;
            this.pb_TeatroMunicipal.TabStop = false;
            // 
            // pb_BancoBanespa
            // 
            this.pb_BancoBanespa.Image = ((System.Drawing.Image)(resources.GetObject("pb_BancoBanespa.Image")));
            this.pb_BancoBanespa.Location = new System.Drawing.Point(12, 473);
            this.pb_BancoBanespa.Name = "pb_BancoBanespa";
            this.pb_BancoBanespa.Size = new System.Drawing.Size(150, 112);
            this.pb_BancoBanespa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_BancoBanespa.TabIndex = 9;
            this.pb_BancoBanespa.TabStop = false;
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.pb_TeatroMunicipal);
            this.Controls.Add(this.pb_BancoBanespa);
            this.Controls.Add(this.pb_ParkLake);
            this.Controls.Add(this.pb_Marathon);
            this.Controls.Add(this.pb_InteractMap);
            this.Controls.Add(this.l_Info);
            this.Controls.Add(this.l_InfoMarathonSkills);
            this.Controls.Add(this.pnl_Down);
            this.Controls.Add(this.pnl_Up);
            this.Name = "Info";
            this.Text = "Info";
            this.Load += new System.EventHandler(this.Info_Load);
            this.pnl_Down.ResumeLayout(false);
            this.pnl_Down.PerformLayout();
            this.pnl_Up.ResumeLayout(false);
            this.pnl_Up.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_InteractMap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Marathon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ParkLake)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_TeatroMunicipal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_BancoBanespa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel pnl_Down;
        public System.Windows.Forms.Label l_Count;
        public System.Windows.Forms.Panel pnl_Up;
        public System.Windows.Forms.Label l_MarathonSkills;
        public System.Windows.Forms.Label l_InfoMarathonSkills;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.Label l_Info;
        private System.Windows.Forms.PictureBox pb_InteractMap;
        private System.Windows.Forms.PictureBox pb_Marathon;
        private System.Windows.Forms.PictureBox pb_ParkLake;
        private System.Windows.Forms.PictureBox pb_TeatroMunicipal;
        private System.Windows.Forms.PictureBox pb_BancoBanespa;
        private System.Windows.Forms.Timer timer;
    }
}