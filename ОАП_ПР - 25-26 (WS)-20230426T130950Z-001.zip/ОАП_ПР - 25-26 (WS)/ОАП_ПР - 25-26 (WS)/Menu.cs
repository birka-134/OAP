﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОАП_ПР___25_26__WS_
{
	public partial class Menu : Form
	{
		public Menu()
		{
			InitializeComponent();
		}
		public DateTime endDate;
		private void Menu_Load(object sender, EventArgs e)
		{
			RoundedButton.RoundButton(btn_MarathonSkills, 20);
			RoundedButton.RoundButton(btn_Time, 20);
			RoundedButton.RoundButton(btn_BMI, 20);
			RoundedButton.RoundButton(btn_BMR, 20);

			endDate = new DateTime(2022, 5, 11, 8, 30, 0);
			timer.Start(); 
		}
		private void timer_Tick(object sender, EventArgs e)
		{
			l_Count.Text = string.Format("{0:dd} дней {0:hh} часов и {0:mm} минут {0:ss} секунд до старта марафона!", endDate - DateTime.Now);
		}

		private void btn_MarathonSkills_Click(object sender, EventArgs e)
		{
			Info Form2 = new Info();
			this.Hide();
			Form2.ShowDialog();
			this.Show();
		}

		private void btn_Time_Click(object sender, EventArgs e)
		{
			Time Form3 = new Time();
			this.Hide();
			Form3.ShowDialog();
			this.Show();
		}

		private void btn_BMI_Click(object sender, EventArgs e)
		{
			BMI Form4 = new BMI();
			this.Hide();
			Form4.ShowDialog();
			this.Show();
		}

		private void btn_BMR_Click(object sender, EventArgs e)
		{
			BMR Form5 = new BMR();
			this.Hide();
			Form5.ShowDialog();
			this.Show();
		}
	}
}
